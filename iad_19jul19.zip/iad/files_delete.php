<?php 
error_reporting(0);
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();
$process_type = $_SESSION['SESSION_process_type'];
	if(isset($_REQUEST["id"]))
	{ 
		$deleteid= $_REQUEST["id"];
		$sql = "select * from file_logs WHERE id = $deleteid";
		$result = mysql_query($sql);
		if(count($result)>0)
		{
			$row = mysql_fetch_array($result);
			$name = $row["file_name"];
			$ticket_number = $row["ticket_number"];
			$role_id = $row["role_id"];
			$created_on = $row["created_on"];
			$updated_by = $row["updated_by"];
			$processtype = $row["assigned_by"];
			$assigned_to = $row["assigned_to"];
			$now = date('Y-m-d');
			$userId = $_SESSION['SESSION_USER_ID'];
			$sqlQuery = "INSERT INTO file_drops(file_name, ticket_number, role_id, created_on, updated_by,assigned_by,assigned_to,deleted_on,deleted_by) 
					VALUES('".$name."','".$ticket_number."','".$role_id."','".$created_on."','".$updated_by."','".$processtype."','".$assigned_to."','".$now."','".$userId."')";
					echo $sqlQuery;
			$result = mysql_query($sqlQuery);

			include('s3_config.php');
			$actual_image_name = $process_type .'/' . $name;
			$success = $s3->deleteObject($bucket,$actual_image_name);
		}	

		$sql = "Delete from file_logs WHERE id = $deleteid";
		$result = mysql_query($sql);
		
		echo "<script>var a = 'Record Deleted Successfully';alert(a);	</script>
		<script language='javascript' type='text/javascript'>window.location='./download_view.php';</script>";
	}
?>	


