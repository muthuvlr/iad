<?php 
error_reporting(0);
include('timeout.php');
require_once("dbcontroller.php");

	$updateid = $_REQUEST["updateid"];
	$user_name= $_REQUEST["user_name"];
	$password= $_REQUEST["password"];
	$first_name= $_REQUEST["first_name"];
	$last_name= $_REQUEST["last_name"];
	$user_level= $_REQUEST["user_level"];
	$short_name= $_REQUEST["short_name"];
	$email_id= $_REQUEST["email_id"];
	$short_nameold= $_REQUEST["short_nameold"];
	$active= $_REQUEST["active"];
	//$password= crypt(strrev($_REQUEST['password']),strrev('pwd321'))
	
	$sql = "UPDATE tbllogin SET user_name='$user_name', password='$password', first_name='$first_name', 
	last_name='$last_name', user_level='$user_level', short_name='$short_name', email_id='$email_id', Active=$active WHERE id = $updateid";

	$result = mysql_query($sql);
	
	$sql1 = "UPDATE tbllogin, tblroles SET tbllogin.role_id = tblroles.id 
	WHERE tbllogin.user_level = tblroles.role_name and tbllogin.role_id = '0'";
	$result = mysql_query($sql1);
	
?>	

<div class="message">Your update was successful.</div><br/>
<br/>

