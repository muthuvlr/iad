<?php
	//Start session
	session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESSION_CR_VERSION']);
	unset($_SESSION['SESSION_USER_ID']);
	unset($_SESSION['SESSION_FIRST_NAME']);
	unset($_SESSION['SESSION_LAST_NAME']);
	unset($_SESSION['SESSION_USER_ROLE']);
	unset($_SESSION['SESSION_USER_SHORTNAME']);
	unset($_SESSION['SESSION_USER_USERNAME']);

	unset($_SESSION['SESSION_role_name']);
	unset($_SESSION['SESSION_role_id']);
	unset($_SESSION['SESSION_export']);
	unset($_SESSION['SESSION_data_delete']);
	unset($_SESSION['SESSION_user_profile']);
	unset($_SESSION['SESSION_roles_update']);
	unset($_SESSION['SESSION_roles_view']);
	unset($_SESSION['SESSION_data_update']);
	unset($_SESSION['SESSION_companylist']);
	unset($_SESSION['SESSION_agentlist']);
	unset($_SESSION['SESSION_productionlist']);

	session_destroy();
	header("location: index.php");
?>