<?php
require_once("dbcontroller.php");

	$qrytype = $_REQUEST["qrytype"];
	$arr=array();
	$i=0;
	$arr[$i] = "-";
	$i	= $i + 1;	

	//$sql = "Select Id,user_name from tbllogin where user_level='$qrytype'";
	$sql = "SELECT tbllogin.Id, tbllogin.user_name FROM  tbllogin 
								inner join tblroles on tblroles.role_name = tbllogin.user_level
								where tblroles.process_type ='$qrytype' order by  tbllogin.user_name";
	$result = mysql_query($sql);
	$num_rows = mysql_num_rows($result);
	
	if($num_rows >0) {
		while($row = mysql_fetch_assoc($result)) {
			$arr[$i] = $row["Id"] . "-" . $row["user_name"];
			$i	= $i + 1;			
		}
	}

	rsort($arr);		
	echo json_encode($arr);

?>