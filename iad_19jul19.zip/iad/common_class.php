<?php
require_once("dbcontroller.php");
class commonclass
{
	function getId($name,$type)
    {
    	if($type == 'client') {
    		$sqlQry = "select id from company_list WHERE company_name ='".$name ."'";
    	} else if($type == 'agent')  {
    		$sqlQry = "select id from agent_list WHERE abb ='".$name ."'";
    	}
		else {
    		$sqlQry = "select id from insurer_list WHERE abbreviation ='".$name ."'";
    	}
		
		
		$cId = 0;
		$result = mysql_query($sqlQry);
		$numRows = mysql_num_rows($result);
		if($numRows >0) {
			$row = mysql_fetch_assoc($result);
			$cId = $row['id'];
			return $cId;
		}
		return $cId;
	}


}

?>	