<?php
error_reporting(-1);
require_once("dbcontroller.php");
include('mail_class.php');
$db_handle = new DBController();


$id = "";
$name_of_client = "";
$customer_id = "";
$policy_number = "";
$policy_type = "";
$insurer = "";
$no_of_workers = "";
$description = "";
$premium = "";
$premium_wgst = "";
$premium_wgst = "";
$commission1 = "";
$commission2 = "";
$agent_name = "";
$agent_com = "";
$referral_name = "";
$referral = "";
$referral_com = "";
$com_paid_by_insurer = "";
$com_paid_outto_referral_date = "";
$com_paid_date = "";
$difference_in_com = "";
$premium_outstanding = "";
$dn ="";
$dn_premium ="";
$premium_paid_to_insurer = "";
$premium_paid_by_client = "";
$address  = "";
$updated_on  = "";
$cell_number  = "";
$com_paid_outto_referral_date = "";
$com_paid_date = "";
//echo $_SESSION['SESSION_HtmlBody'];
if(!empty($_POST["submit"])) {
	 
	$aid = $_GET["id"];
	
	$bodyContent = $_SESSION['SESSION_HtmlBody'];
	$Omail = new mailclass();
	$Omail->mailfun($bodyContent,$aid);
}

if(!empty($_REQUEST["mid"])) {
	$arrId = explode(",", $_REQUEST["mid"]);
}
if(isset($_GET["id"])) {
	$arrId = explode(",", $_GET["id"]);
}

if( !empty($arrId) )
{ 
	if(!empty($_REQUEST["mid"])) {
		$arrId = explode(",", $_REQUEST["mid"]);
	} else {
		$arrId = explode(",", $_REQUEST["id"]);
	}
	foreach ($arrId as $key => $gid) {

		$sql = "SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type, ilist.insurer_name, pde.no_of_workers, pde.description, pde.premium, pde.premium_wgst,pde.dn_premium, pde.commission1, pde.commission2,pde.agency_com, alist.agent_name, pde.agent_com, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.premium_paid_to_insurer, pde.premium_paid_by_client,clist.address,pde.updated_on,alist.cell_number FROM production_details as pde
				INNER JOIN company_list as clist on clist.id = pde.company_id  
				INNER JOIN agent_list as alist on alist.id = pde.agent_id  
				LEFT JOIN insurer_list as ilist on ilist.id = pde.insurer
				LEFT JOIN tbllogin as login on login.id = pde.updated_by where pde.id = $gid";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);

		$id = $row['id'];
		$name_of_client = $row["name_of_client"];
		$customer_id = $row["customer_id"];
		$policy_number = $row["policy_number"];
		$policy_type = $row["policy_type"];
		$insurer = $row["insurer_name"];
		$no_of_workers = $row["no_of_workers"];
		$description = $row["description"];
		$premium = $row["premium"];
		$premium_wgst = $row["premium_wgst"];
		$dn_premium = $row["dn_premium"];
		$premium_wgst = number_format($premium_wgst,2);
		$dn_premium = number_format($dn_premium,2);
		$commission1 = $row["commission1"];
		$commission2 = $row["commission2"];
		$agent_name = $row["agent_name"];
		$agent_com = $row["agent_com"];
		$referral_name = $row["referral_name"];
		$referral = $row["referral"];
		$referral_com = $row["referral_com"];
		$com_paid_by_insurer = $row["com_paid_by_insurer"];
		$com_paid_outto_referral_date = $row["com_paid_outto_referral_date"];
		$com_paid_date = $row["com_paid_date"];
		$difference_in_com = $row["difference_in_com"];
		$premium_outstanding = $row["premium_outstanding"]; 
		$premium_outstanding = number_format($premium_outstanding,2);
		$dn = $row["dn"];
		$premium_paid_to_insurer = $row["premium_paid_to_insurer"];
		$premium_paid_to_insurer = number_format($premium_paid_to_insurer,2);
		$premium_paid_by_client = $row["premium_paid_by_client"];
		$premium_paid_by_client = number_format($premium_paid_by_client,2);
		$address  = $row["address"];
		$updated_on  = $row["updated_on"];
		$cell_number  = $row["cell_number"];

		$com_paid_outto_referral_date = date('d-m-Y',strtotime($row['com_paid_outto_referral_date']));
		$com_paid_date = date('d-m-Y',strtotime($row['com_paid_date']));
		$updated_on = date('d-M-y',strtotime($row['updated_on']));

$site_logo = "http://" . $_SERVER['SERVER_NAME']."/iad/img/logo.jpg";


$html = '
<html>
<head>
	
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<style type="text/css">
		body,div,table,thead,tbody,tfoot,tr,th,td,p { }
		a.comment-indicator:hover + comment { background:#ffd; position:absolute; display:block; border:1px solid black; padding:0.5em;  } 
		a.comment-indicator { background:red; display:inline-block; border:1px solid black; width:0.5em; height:0.5em;  } 
		comment { display:none;  } 
		.i{font-style:italic}
	</style>
	
</head>

<body>
<table cellspacing="0" border="0" >
	<colgroup width="131"></colgroup>
	<colgroup width="103"></colgroup>
	<colgroup width="102"></colgroup>
	<colgroup width="161"></colgroup>
	<colgroup width="120"></colgroup>
	<colgroup width="87"></colgroup>
	<thead border="0" cellspacing="0"><tr><td  colspan="6"></td></tr></thead>
	<tr border="0" cellspacing="0">
	<td border="0" cellspacing="0"><img src="'.$site_logo.'" width="62" height="44" hspace="39" vspace="10" /></td>
		<td  border="0" cellspacing="0" colspan="5" height="64" align="right" valign=bottom style="padding: 0 10px 10px 0;"><font face="" size=7 color="#8DB4E3" style="font-size: 51px;" class="i"><em>Debit Note</em></font></td>
		</tr>
	<tr border="0" cellspacing="0">
		<td border="0" cellspacing="0" style="border:none" colspan="4" height="28" align="left" valign=middle><font face="Calibri" style="font-size: 18.5px;" color="#404040">&nbsp;&nbsp;Maraicar Agency Pte Ltd</font></td>
		<td style="border:none" align="left" valign=middle><font face="Calibri"  color="#404040" style="font-size: 13.5px;" > Date:</font></td>
		<td style="border:none" align="left" valign=middle><font face="Calibri" style="" color="#404040" style="font-size: 13.5px;">'.$updated_on.' </font></td>
	</tr>
	<tr border="0" cellspacing="0">
		<td border="0" cellspacing="0" style="border:none;     vertical-align: top;" colspan="4" rowspan="2" height="44" align="left" valign=middle><font face="Calibri" color="#404040" style="font-size: 12px;">&nbsp;&nbsp; 201327202R</font></td>
		<td border="0" cellspacing="0" style="border:none" align="left" valign=middle><font face="Calibri"  color="#404040" style="font-size: 13.5px;">Note #:</font></td>
		<td border="0" cellspacing="0" style="" align="left" valign=middle sdval="3000" sdnum="1033;"><font face="Calibri" style="" color="#404040" style="font-size: 13.5px;">'.$dn.' </font></td>
	</tr>
	<tr>
		<td style="border:none" align="left" valign=middle><font face="Calibri"  color="#404040" style="font-size: 13.5px;">Customer ID:</font></td>
		<td style="border:none" align="left" valign=middle sdval="1001" sdnum="1033;"><font face="Calibri" style="font-size: 13.5px;" color="#404040">'.$customer_id .' </font></td>
	</tr>
	<tr>
		<td style="border:none; vertical-align: top;" rowspan="2" height="55" align="left" valign=middle><font face="Calibri" color="#404040"  style="font-size: 13.5px;">&nbsp;&nbsp;To:</font></td>
		<td style="border:none" colspan="5" rowspan="2" align="left" valign=top><font face="Calibri"  style="font-size: 13.5px;     text-transform: uppercase;    /* white-space: pre;*/" color="#404040">'.ucfirst($name_of_client) .'<br>'.nl2br($address).' <br/></font></td>
		</tr>
	<tr>
		</tr>
	<tr bgcolor="#8DB4E3" border="1" bordercolor="#538ED5" style="" >
		<td border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" colspan="3" height="20" align="center" valign=middle ><font face="Cambria" color="#fff" style="font-size: 10.7px; " >Agent name</font></td>
		<td  border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size: 10.7px; " >Contact no:</font></b></td>
		<td border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size: 10.7px; " >Payment Terms</font></b></td>
		<td border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size: 10.7px; " >Due Date</font></b></td>
	</tr>
	<tr border="1" bordercolor="#538ED5">
		<td border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" colspan="3" height="20" align="left" valign=middle><font face="Cambria" style="text-transform: capitalize; font-size: 13.5px;" color="#404040">&nbsp;&nbsp;'.ucfirst($agent_name).' </font></td>
		<td border="1" border-color="#538ED5" style=" padding-left: 10px;border:1px solid #538ED5 !important;" align="left" valign=middle sdval="93848585" sdnum="1033;"><font face="Cambria" style="font-size: 13.5px;" color="#404040">&nbsp;&nbsp;'.$cell_number .'</font></td>
		<td border="1" border-color="#538ED5" bgcolor="#538ED5" style=" border:1px solid #538ED5 !important; background: #538ED5; padding-left: 5px; text-align: center;" align="center" valign=middle><b><font face="Cambria" size color="#fff" style="font-size: 11px;">Due upon receipt</font></b></td>
		<td border="1" border-color="#538ED5" style="border:1px solid #538ED5 !important" align="center" valign=middle sdval="42736" sdnum="1033;"><font face="Cambria" style="" color="#404040;font-size:13.5px;">'.$updated_on. '</font></td>
	</tr>
	<tr border="1" bordercolor="#C5D9F1" >
		<td border="1" bgcolor="#8DB4E3" style="background: #8DB4E3; border:1px solid #538ED5 !important" height="20" align="center" valign=bottom><b><font face="Cambria" style="font-size:11px;" color="#fff">Insurer </font></b></td>
		<td border="1" style="border:1px solid #538ED5 !important" colspan="5" height="20" align="center" valign=bottom sdnum="1033;0;0.00" style="border:1px solid #538ED5 !important;"><font face="Cambria" size=2 style="font-size:13.5px;" color="#404040">'.$insurer.'</font></td>
		</tr>
	<tr bgcolor="#8DB4E3" style="background: #8DB4E3;">
		<td border="1" style="border:1px solid #538ED5 !important" height="20" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size:11px;">Policy number</font></b></td>
		<td border="1" style="border:1px solid #538ED5 !important" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size:11px;">No of workers</font></b></td>
		<td border="1" style="border:1px solid #538ED5 !important" colspan="3" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size:11px;">Description</font></b></td>
		<td border="1" style="border:1px solid #538ED5 !important" align="center" valign=middle ><b><font face="Cambria" color="#fff" style="font-size:11px;">Line Total</font></b></td>
	</tr>
	<tr border="1" bordercolor="#C5D9F1" style="border:1px solid #538ED5 !important;">
		<td border="1" bordercolor="#C5D9F1" style="border: 1px solid #C5D9F1 !important" height="278" align="center" valign=top sdnum="1033;0;0.00"><font face="Cambria" color="#404040">'.$policy_number.'</font></td>
		<td border="1" bordercolor="#C5D9F1"  style="border: 1px solid #C5D9F1 !important" align="center" valign=top sdval="6" sdnum="1033;0;0"><font face="Cambria" color="#404040">'.$no_of_workers.'</font></td>
		<td border="1" bordercolor="#C5D9F1"  style="border: 1px solid #C5D9F1 !important; /*white-space:pre-wrap;*/ padding-left:10px;" colspan="3" align="left" valign=top><font face="Cambria" color="#404040">'.nl2br($description).'</font></td>
		<td bgcolor="#DBE5F1" border="1" bordercolor="#C5D9F1"  style="background: #DBE5F1;border:1px solid #C5D9F1 !important" align="right" valign=top sdval="1070"><font face="Calibri" color="#404040" align="left" style="font-size:13.5px; float: left;">&nbsp; $</font><font face="Calibri" align="" color="#404040"  style="font-size:13.5px;"> '.$dn_premium.' &nbsp;</font></td>
	</tr>
	<tr>
		<td style="border:none" height="20" colspan="5" align="left" valign=middle><u><font face="Cambria"  color="#404040" style="font-size:11px;">IMPORTANT NOTICE</font></u></td>
		<td bgcolor="#DBE5F1" style="background: #DBE5F1;border:none"  valign=top sdval="1070"><font face="Calibri" color="#404040" align="left" style="font-size:13.5px;  float: left;">&nbsp; $</font><font face="Calibri" color="#404040"  style="font-size:13.5px; float: right;"> '.$dn_premium.' &nbsp;</font></td>
	</tr>
	<tr>
		<td style="border:none" colspan="4" height="20" align="left" valign=middle><font face="Cambria"  color="#404040" style="font-size:11px;">PREMIUM PAYMENT WARRANT IS IMPOSED BY INSURER</font></td>
		<td style="" align="left" valign=middle><i><font face="Cambria" color="#404040" style="font-size:11px;">less Paid</font></i></td>
		<td style="border:none" align="right" valign=top><font face="Calibri" color="#404040" align="left" style="font-size:13.5px;  float: left;">&nbsp; $</font><font face="Calibri" color="#404040"  style="font-size:13.5px; float: right;"> '.$premium_paid_by_client.' &nbsp;</font></td>
	</tr>
	<tr>
		<td style="border:none" colspan="4" height="20" align="left" valign=middle><font face="Cambria" style="font-size:11px;"  color="#404040">TO AVOID AUTOMATIC TERMINATION OF POLICY BY INSURER,</font></td>
		<td style="border:none" align="left" valign=middle><i><font face="Cambria" color="#404040" style="font-size:11px;">less Paid</font></i></td>
		<td style="border:none" align="right" valign=top><font face="Calibri" color="#404040" align="left" style="font-size:13.5px;  float: left;">&nbsp; $</font><font face="Calibri" color="#404040"  style="font-size:13.5px; float: right;"> 0.00 &nbsp;</font></td>
		
	</tr>
	<tr>
		<td style="border:none" colspan="4" height="20" align="left" valign=middle><font face="Cambria"  color="#404040" style="font-size:11px;">PLEASE MAKE PAYMENT BY THE DUE DATE.</font></td>
		<td style="border:none" align="left" valign=middle><font face="Cambria" color="#404040" style="font-size:11px;">Net Payable</font></td>
		<td border="1" bgcolor="#DBE5F1" bordercolor="#538ED5" style="border:1px solid #538ED5 !important" align="right" valign=top><font face="Calibri" color="#404040" align="left" style="font-size:13.5px;  float: left;">&nbsp; $</font><font face="Calibri" color="#404040"  style="font-size:13.5px; float: right;"> '.$premium_outstanding .'&nbsp;</font></td>
	</tr>
	<tr>
		<td style="border:none" height="20" align="left" colspan="6" valign=middle><b><font face="Cambria"  color="#404040"></font></b></td>
		<!--<td style="border-top: 1px solid #fff; border-bottom: 1px solid #000000" align="left" valign=middle><b><font face="Cambria"  color="#404040"><br></font></b></td>
		<td style="border-top: 1px solid #fff; border-bottom: 1px solid #000000" align="left" valign=middle><b><font face="Cambria"  color="#404040"><br></font></b></td>
		<td style="border-top: 1px solid #fff; border-bottom: 1px solid #fff; border-right: 1px solid #000000" align="left" valign=middle><b><font face="Cambria"  color="#404040"><br></font></b></td>
		<td style="border:none" align="left" valign=middle><b><font face="Cambria"  color="#404040"><br></font></b></td>
		<td style="border:none" align="right" valign=middle"><b><font face="Cambria"  color="#404040"><br></font></b></td>-->
	</tr>
	
	<tr>
		<td style="border:none;" colspan="6" rowspan="2" height="40" align="center" valign=middle><font face="Cambria" color="#404040" style="font-size:11px;">CHEQUES TO BE CROSSED AND MADE PAYABLE TO: MARAICAR AGENCY PTE LTD<br>Thank you for your business!</font></td>
	</tr>
	<tr></tr>
	<tr>
		<td style="border:none; " colspan="6" height="20" align="center" valign=middle><font face="Cambria" color="#538ED5" style="font-size:11px;">Tel:(65)65227827   Fax:(65)62899940</font></td>
		</tr>
	<tr>
		<td style="border:none; " colspan="6" height="21" align="center" valign=bottom><em><font face=""  color="#404040" style="font-size:11px;">THIS IS NOT A TAX INVOICE. THE RESPECTIVE INSURANCE COMPANY\'S TAX INVOICE WILL BE SENT SHORTLY.</font></em></td>
		</tr>
	<tr>
		<td style="" colspan="6" height="21" align="center" valign=bottom><font face="Cambria" color="#404040"><br></font></td>
		</tr>
</table>
</body>

</html>';

		$_SESSION['SESSION_HtmlBody'] = $html;
		
		if(!empty($_REQUEST["mid"])) {
			$bodyContent = $_SESSION['SESSION_HtmlBody'];
			$Omail = new mailclass();
			$Omail->mailfun($bodyContent,$gid);
		} else {

			echo $html;
		}
	}
}
if(!empty($_REQUEST["mid"])) {
	echo "<script language='javascript' type='text/javascript'> window.location='./production_inline.php'; </script>";
}
?>