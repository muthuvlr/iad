<?php
	//Start session
	session_start();
	
	//Check whether the session variable SESSION_USER_ID is present or not
	if(!isset($_SESSION['SESSION_USER_ID']) || (trim($_SESSION['SESSION_USER_ID']) == '')) {
	header("location: index.php");
	exit();
	}
?>