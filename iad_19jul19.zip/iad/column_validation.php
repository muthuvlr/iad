<?php
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

	if(!empty($_REQUEST["user_name"])) 
	{
		if(!empty($_REQUEST["updateid"])) {
			$sql = "select user_name from tbllogin WHERE user_name='".$_REQUEST["user_name"]."' and Id !=".$_REQUEST["updateid"];
		}
		else{
			$sql = "select user_name from tbllogin WHERE user_name='".$_REQUEST["user_name"]."'";
		}
		$result = mysql_query($sql);
		$numrows = mysql_num_rows($result);
		
		if($numrows == 0) {
			echo "0";
		}else {
			echo "1";
		}
	}
	if(!empty($_REQUEST["role_name"])) 
	{
		if(!empty($_REQUEST["updateid"])) {
			$sql = "select role_name from tblroles WHERE role_name='".$_REQUEST["role_name"]."' and id !=".$_REQUEST["updateid"];
		}
		else{
			$sql = "select role_name from tblroles WHERE role_name='".$_REQUEST["role_name"]."'";
		}
		$result = mysql_query($sql);
		$numrows = mysql_num_rows($result);
		
		if($numrows == 0) {
			echo "0";
		}else {
			echo "1";
		}
	}
	if(!empty($_REQUEST["name_of_client"])) 
	{
		$sql = "select company_name from company_list WHERE company_name='".$_REQUEST["name_of_client"]."'";
		$result = mysql_query($sql);
		$numrows = mysql_num_rows($result);
		
		if($numrows == 0) {
			echo "0";
		}else {
			echo "1";
		}
	}
	if(!empty($_REQUEST["agent_name"])) 
	{
		$sql = "select agent_name from agent_list WHERE agent_name='".$_REQUEST["agent_name"]."'";
		$result = mysql_query($sql);
		$numrows = mysql_num_rows($result);
		
		if($numrows == 0) {
			echo "0";
		}else {
			echo "1";
		}
	}
?>

