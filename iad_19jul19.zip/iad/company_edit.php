<?php 
error_reporting(0);
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

$imgclear = 0;
$customer_id = $_POST["customer_id"];
$company_name = $_POST["company_name"];
//$user_id = $_POST["user_id"];
$email_id = $_POST["email_id"];
$address = $_POST["address"];
$other_email_id = $_POST["other_email_id"];
$manpower_agent = $_POST["manpower_agent"];
$gia_agent = $_POST["gia_agent"];
$work_number = $_POST["work_number"];
$person_to_contact = $_POST["person_to_contact"];
$cell_number = $_POST["cell_number"];

$customer_id = str_replace("'","\'",$customer_id);
$company_name = str_replace("'","\'",$company_name);
//$user_id = str_replace("'","\'",$user_id);
$user_id = "";
$address = str_replace("'","\'",$address);
$gia_agent = str_replace("'","\'",$gia_agent);
$manpower_agent = str_replace("'","\'",$manpower_agent);
$email_id = str_replace("'","\'",$email_id);
$person_to_contact = str_replace("'","\'",$person_to_contact);
$other_email_id = str_replace("'","\'",$other_email_id);

date_default_timezone_set("Asia/Kolkata");

$active_status = 1;

$now = date('Y-m-d');
$userId = $_SESSION['SESSION_USER_ID'];
if(!empty($_GET["id"])) {
	if(!empty($_POST["submit"])) {

		$sqlQuery = "UPDATE company_list set 
			customer_id = '".$customer_id."', 
			company_name = '".$company_name."', 
			user_id = '".$user_id."', 
			email_id = '".$email_id."', 
			address = '".$address."', 
			other_email_id = '".$other_email_id."', 
			manpower_agent = '".$manpower_agent."', 
			gia_agent = '".$gia_agent."', 
			work_number = '".$work_number."', 
			person_to_contact = '".$person_to_contact."', 
			cell_number = '".$cell_number."',
			active_status = ".$active_status.", 
			updated_on = '".$now."', 
			updated_by = '".$userId."'";

		$condtion = " WHERE  id=".$_GET['id'];
		$sqlQuery = $sqlQuery . $condtion; 

		$result = mysql_query($sqlQuery);
		if(!$result){
			$message = "Problem in Editing! Please Retry!";
		} else {
			echo "<script language='javascript' type='text/javascript'>window.location='./company_view.php';</script>";
			//header("Location:brand_view.php");
		}
	}
	$result = $db_handle->runQuery("SELECT * FROM company_list WHERE id='" . $_GET["id"] . "'");
}
else{
	if(!empty($_POST["submit"])) {
		if($customer_id!="" || $company_name!="" || $email_id!="" && $address!="" || $other_email_id!="" || $manpower_agent!="" || $gia_agent!="" || $work_number!="" || $person_to_contact!="" || $cell_number!=""){
		$sqlQuery = "INSERT INTO company_list(customer_id, company_name, user_id, email_id, address, other_email_id, manpower_agent, gia_agent, work_number, person_to_contact, cell_number,  active_status, created_on, created_by, updated_on, updated_by) 
		VALUES('".$customer_id."','".$company_name."','".$user_id."','".$email_id."','".$address."','".$other_email_id."','".$manpower_agent."','".$gia_agent."','".$work_number."','".$person_to_contact."','".$cell_number."',".$active_status.",'". $now."','".$userId."','".$now."','".$userId."')";
		
		$result = mysql_query($sqlQuery);
		$insert=true;
		}
		if(!$insert){
			$message="Please Enter the values to Avoid Dummy entries.";
		}
		else if(!$result && $insert){
				$message="Problem in Adding to database. Please Retry.";
		} else {
			echo "<script language='javascript' type='text/javascript'>window.location='./company_view.php';</script>";
		}
		
	}
}
if(!empty($_GET["lid"])) {
	$result = $db_handle->runQuery("SELECT * FROM company_list WHERE id='" . $_GET["lid"] . "'");
}

?>	
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function () {
	function InsertBreak(e){
		//check for return key=13
		if (parseInt(e.keyCode)==13) {
			//get textarea object
			var objTxtArea;
			objTxtArea=document.getElementById("test");
	//insert the existing text with the <br>
		objTxtArea.innerText=objTxtArea.value+"\n";
		}
	}
	$("#clear").click(function(){
		$('#customer_id').val("");
		$('#company_name').val("");
		//$('#user_id').val("");
		$('#email_id').val("");
		$('#address').val("");
		$('#other_email_id').val("");
		$('#manpower_agent').val("");
		$('#gia_agent').val("");
		$('#work_number').val("");
		$('#person_to_contact').val("");
		$('#cell_number').val("");
		$('#active_status').val("1");
	    });
    });
</script>

<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%">
<form action="" name="bform" method='post' enctype="multipart/form-data" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Add/Update Company Details</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:370px;">
		<?php
		if(isset($_GET["id"]))
		{
			$id = $result[0]["id"];
			$customer_id = $result[0]["customer_id"];
			$company_name = $result[0]["company_name"];
			//$user_id = $result[0]["user_id"];
			$email_id = $result[0]["email_id"];
			$address = $result[0]["address"];
			$other_email_id = $result[0]["other_email_id"];
			$manpower_agent = $result[0]["manpower_agent"];
			$gia_agent = $result[0]["gia_agent"];
			$work_number = $result[0]["work_number"];
			$person_to_contact = $result[0]["person_to_contact"];
			$cell_number = $result[0]["cell_number"];
			$updated_by = $result[0]["updated_by"];
			$active_status = $result[0]["active_status"];
		}
		if(isset($_GET["lid"]))
		{   
			$customer_id = $result[0]["customer_id"];
			$company_name = $result[0]["company_name"];
			//$user_id = $result[0]["user_id"];
			$email_id = $result[0]["email_id"];
			$address = $result[0]["address"];
			$other_email_id = $result[0]["other_email_id"];
			$manpower_agent = $result[0]["manpower_agent"];
			$gia_agent = $result[0]["gia_agent"];
			$work_number = $result[0]["work_number"];
			$person_to_contact = $result[0]["person_to_contact"];
			$cell_number = $result[0]["cell_number"];
			$image = $result[0]["image"];
		}
		?>
			<table>
			<tr><td colspan="5" style="text-align:center">
				<?php 
					echo '<h3 style="color:red">'. $message.'</h3>'; 
				?>
				</td></tr>
			<tr>
				<td>
				<label>Company Name : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="company_name" name="company_name" value="<?php echo $company_name;?>"/>
				</td>

				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label style="width:160px;">Customer Id : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="customer_id" name="customer_id" value="<?php echo $customer_id;?>"/>
				</td>				
			</tr>

			<tr>
				<!--<td>
				<label style="width:130px;">User Id : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="user_id" name="user_id" value="<?php echo $user_id;?>"/>
				</td>-->
				<td>
				<label>Email Id : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="email_id" name="email_id" value="<?php echo $email_id;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label style="width:130px;">Address : </label>
				</td>
				<td>
				<textarea rows="2" cols="250" name="address" class="textfield" onkeydown="InsertBreak(event);" id="address" style="width:97%"/><?php echo $address;?></textarea>
				<!--<input  style="width:250px;" type="text" id="address" name="address" value="<?php //echo $address;?>"/>-->
				</td>
			</tr>

			<tr>
				
				
				<td>
				<label style="width: 160px;">Other Email Ids: (comma separated) </label>
				</td>
				<td>
					<textarea rows="2" cols="250" name="other_email_id" class="textfield" id="other_email_id" style="width:97%"/><?php echo $other_email_id;?></textarea>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
                <label>Manpower Agent : </label>
                </td>
                <td colspan="4">
                <input style="width:250px;" type="text" id="manpower_agent" name="manpower_agent" value="<?php echo $manpower_agent;?>"/>
                </td>
                <td>
                </td>
			</tr>

			<tr>
			
			</tr>
			<tr>
				<td>
				<label>GIA Agent :</label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="gia_agent" name="gia_agent" value="<?php echo $gia_agent;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label>Work Number : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="work_number" name="work_number" value="<?php echo $work_number;?>"/>
				</td>
			</tr>
			<tr>
				<td>
				<label>Person to Contact : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="person_to_contact" name="person_to_contact" value="<?php echo $person_to_contact;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label>Cell Number : </label>
				</td>
				<td>
				<input  style="width:250px;" type="text" id="cell_number" name="cell_number" value="<?php echo $cell_number;?>"/>
				</td>
			</tr>
			
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td></td>
				<td>
				<table>
				<tr>
				<td><input style="width:80px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit" onclick="return Validate()"></td>
				<td><input style="width:80px;" class="btn btn-primary span4" id="clear" name="clear" type="button" value="Clear"></td>
				<td><input style="width:80px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='company_view.php';"></td>
				</tr>
				</table>
				</td>
			</tr>
		</table>

	</div>
	</div>
	</div>
	</section>
	
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>