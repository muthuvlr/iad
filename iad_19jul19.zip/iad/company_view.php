<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("perpage.php");	
require_once("dbcontroller.php");

$db_handle = new DBController();
	
	$company_name = "";
	$customer_id = "";
	$user_id = "";
	$email_id = "";
	$person_to_contact = "";
	$cell_number = "";
	$manpower_agent = "";
	$gia_agent = "";
	$sesDataUpdate = $_SESSION['SESSION_data_update'];
	$sesExport = $_SESSION['SESSION_export'];
	$dataDelete = $_SESSION['SESSION_data_delete'];
	$queryCondition = "";
	if(isset($_POST['search'])) {
		foreach($_POST["search"] as $k=>$v){

			if(!empty($v)) {
				$queryCases = array("company_name","customer_id","user_id","person_to_contact","cell_number","manpower_agent","gia_agent","email_id");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}

				switch($k) {
					case "company_name":
						$company_name = $v;
						$queryCondition .= "company.company_name LIKE '%" . $v . "%'";
						break;
					case "customer_id":
						$customer_id = $v;
						$queryCondition .= "company.customer_id LIKE '%" . $v . "%'";
						break;
					case "user_id":
						$user_id = $v;
						$queryCondition .= "company.user_id LIKE '%" . $v . "%'";
						break;
					case "email_id":
						$email_id = $v;
						$queryCondition .= "company.email_id LIKE '%" . $v . "%'";
						break;
					case "person_to_contact":
						$person_to_contact = $v;
						$queryCondition .= "company.person_to_contact LIKE '%" . $v . "%'";
						break;
					case "cell_number":
						$cell_number = $v;
						$queryCondition .= "company.cell_number LIKE '%" . $v . "%'";
						break;
					case "manpower_agent":
						$manpower_agent = $v;
						$queryCondition .= "company.manpower_agent LIKE '%" . $v . "%'";
						break;
					case "gia_agent":
						$gia_agent = $v;
						$queryCondition .= "company.gia_agent LIKE '%" . $v . "%'";
						break;
				}
				$_SESSION['SESSION_customer_id'] = $customer_id;
				$_SESSION['SESSION_company_name'] = $company_name;
				$_SESSION['SESSION_user_id'] = $user_id;
				$_SESSION['SESSION_email_id'] = $email_id;
				$_SESSION['SESSION_manpower_agent'] = $manpower_agent;
				$_SESSION['SESSION_gia_agent'] = $gia_agent;
				$_SESSION['SESSION_cell_number'] = $cell_number;
				$_SESSION['SESSION_person_to_contact'] = $person_to_contact;
				$_SESSION['SESSION_company_EXPORT'] = '';
				$_SESSION['SESSION_company_page'] = '';
			}
		}
	}
	
	$sql = "SELECT company.id, company.company_name, company.customer_id, company.user_id, company.email_id, company.address,company.other_email_id,company.manpower_agent,company.gia_agent,company.work_number,company.person_to_contact,company.cell_number, company.updated_by, login.user_name, company.created_on FROM company_list as company 
			LEFT JOIN tbllogin as login on login.id = company.updated_by" . $queryCondition;
	$orderby = " GROUP BY company.id ORDER BY id desc"; 

	$href = 'company_view.php';					

	if(isset($_GET["action"])){
		$_SESSION['SESSION_company_page'] = '';
		$_SESSION['SESSION_company_name'] = '';
		$_SESSION['SESSION_customer_id'] = '';
		$_SESSION['SESSION_user_id'] = '';
		$_SESSION['SESSION_email_id'] = '';
		$_SESSION['SESSION_manpower_agent'] = '';
		$_SESSION['SESSION_gia_agent'] = '';
		$_SESSION['SESSION_cell_number'] = '';
		$_SESSION['SESSION_person_to_contact'] = '';
		$_SESSION['SESSION_company_EXPORT'] = $sql;
	}else if(!empty($_SESSION['SESSION_company_EXPORT'])){
		$sql = $_SESSION['SESSION_company_EXPORT']; 	
	}else{
		$_SESSION['SESSION_company_EXPORT'] = $sql;
	}

	$perPage = 10; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
		$_SESSION['SESSION_company_page'] = $page;
	} else {
		if(isset($_SESSION['SESSION_company_name'])) {
			$page = $_SESSION['SESSION_company_page'];
		}
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 

	$result = $db_handle->runQuery($query);

	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}
	$company_name = $_SESSION['SESSION_company_name'];
	$customer_id = $_SESSION['SESSION_customer_id'];
	$user_id = $_SESSION['SESSION_user_id'];
	$email_id = $_SESSION['SESSION_email_id'];
	$manpower_agent = $_SESSION['SESSION_manpower_agent'];
	$gia_agent = $_SESSION['SESSION_gia_agent'];
	$cell_number = $_SESSION['SESSION_cell_number'];
	$person_to_contact = $_SESSION['SESSION_person_to_contact'];

?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
<script type="text/javascript">
$(document).ready(function () 
{

	$('.clsdelete').click(function()
	{
		var essay_id = $(this).attr('id');
		var x;
		if (confirm("Do you want to delete?") == true) 
		{
			$.ajax({
			  type : 'post',
			   url : 'company_delete.php?', // in here you should put your query 
			   data :{action:'delete',id:essay_id}, // here you pass your id via ajax .
			  
						 // in php you should use $_POST['post_id'] to get this value 
			success : function(r)
			   {
				  // now you can show output in your modal 
				  $('#mymodal').show();  // put your modal id 
				 $('.something').show().html(r);
			   }
			});

		} else 
		{
			//x = "You pressed Cancel!";
			//alert(x + essay_id);
		}
    });
});
</script>
<script type="text/javascript">
	 $(document).ready(function () {
		//alert('hi');
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#dateofupload').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        });
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">

	<!-- Individual Page Widget-->
	<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Company Listing</span>
	</div>
	<body>
		
    <div id="toys-grid">      
			<form name="frmSearch" method="post" action="company_view.php">
			
			<div class="search-box" style="width:98%; height:74px;">
			<p class="p-tag">
			<input style="width:19%;" type="text" placeholder="Company Name" name="search[company_name]" value="<?php echo $company_name; ?>"	/>
			<input style="width:19%;" type="text" placeholder="Customer Id" name="search[customer_id]" value="<?php echo $customer_id; ?>"	/>
			<!--<input style="width:19%;" type="text" placeholder="User Id" name="search[user_id]" value="<?php echo $user_id; ?>"	/>-->
			<input style="width:19%;" type="text" placeholder="Email Id" name="search[email_id]" value="<?php echo $email_id; ?>"	/>
			
			<input style="width:19%;" type="text" placeholder="Manpower Agent" id="manpower_agent"  name="search[manpower_agent]" value="<?php echo $manpower_agent; ?>"	/>
			<input style="width:8%;" type="submit" name="go" class="btnSearch" value="Search..">
			<input style="width:8%;" name="reset" type="reset" class="btnSearch" value="Reset.." onclick="window.location='company_view.php?action=reset'">
			<input style="width:19%;" type="text" placeholder="GIA Agent" name="search[gia_agent]" value="<?php echo $gia_agent; ?>"	/>
			<input style="width:19%;" type="text" placeholder="Cell Number" name="search[cell_number]" value="<?php echo $cell_number; ?>"	/>
			
			<input style="width:19%;" type="text" placeholder="Person to Contact" name="search[person_to_contact]" value="<?php echo $person_to_contact; ?>"	/>
			<label style="width:19%;display: inline-block; padding: 4px;"></label>
			<?php if ($sesDataUpdate == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Addnew" onclick="window.location='company_edit.php'">
			<?php } 
			if ($sesExport == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Export" onclick="window.location='company_export.php'">
			<?php } ?>
			</p>
			</div>


			<div style="width:100%; height:500px; overflow:auto;">
			<table style="float:left;" class="table table-bordered">
        <thead>
			<tr>
				<th style="width:5%;"><strong>Sl.No</strong></th>
			    <th style="width:15%;"><strong>Company Name</strong></th>
				<th style="width:10%;"><strong>Customer Id</strong></th>
				<!--<th style="width:10%;"><strong>User Id</strong></th>-->
				<th style="width:10%;"><strong>Email Id 1</strong></th>
				<th style="width:10%;"><strong>Email Id 2</strong></th>
				<th style="width:10%;"><strong>Address</strong></th>
				<th style="width:10%;"><strong>Manpower Agent</strong></th>
				<th style="width:10%;"><strong>GIA Agent</strong></th>
				<th style="width:10%;"><strong>Work No</strong></th>
				<th style="width:10%;"><strong>Cell No</strong></th>
				<th style="width:15%;"><strong>Person to Contact</strong></th>
				<?php 
				if ($sesDataUpdate == "1") {?>
				<th style="width:5%;"><strong>Edit</strong></th>
				<?php } if ($dataDelete == "1") { ?>
				<th style="width:5%;"><strong>Delete</strong></th>
				<?php } ?>				
			</tr>
				</thead>
				<tbody>
					<?php
					if(count($result)>0){
						foreach($result as $k=>$v) {
						if(is_numeric($k)) {
					?>
						<tr>
						<td><?php echo $start+$k+1; ?></td>
						<td><?php echo $result[$k]["company_name"]; ?></td>
						<td><?php echo $result[$k]["customer_id"]; ?></td>
						<!--<td><?php //echo $result[$k]["user_id"]; ?></td> -->
						<td><?php echo $result[$k]["email_id"]; ?></td> 
						<td><?php echo $result[$k]["other_email_id"]; ?></td> 
						<td><?php echo $result[$k]["address"]; ?></td> 
						<td><?php echo $result[$k]["manpower_agent"]; ?></td> 
						<td><?php echo $result[$k]["gia_agent"]; ?></td> 
						<td><?php echo $result[$k]["work_number"]; ?></td> 
						<td><?php echo $result[$k]["cell_number"]; ?></td> 
						<td><?php echo $result[$k]["person_to_contact"]; ?></td> 
					
						<?php
						if ($sesDataUpdate == "1") {?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"];?>" class="abc" onclick="window.location.href = 'company_edit.php?id=' + <?php echo $result[$k]["id"];?>">
								<img id="eidtico" name="eidtico" src="img/edit-icon.png" class="utopia-widget-icon" >
								</a>
						</td>
						<?php } if ($dataDelete == "1") { ?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"]; ?>" class="clsdelete" >
									<img id="deleteico" name="deleteico" src="img/delete-icon.png" class="utopia-widget-icon"></a>
						</td>
						<?php } ?> 
						</tr>
						<?php
							}
						}
					}
					if(isset($result["perpage"])) {
					?>
					<tr>
					<td colspan="13" align=right> <?php echo $result["perpage"]; ?></td>
					</tr>
					<?php } ?>
				<tbody>
			</table>
			</div>
			</form>	
		</div>
	</body>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
</section>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>