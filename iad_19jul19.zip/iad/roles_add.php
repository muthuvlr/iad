<?php 
include('auth.php'); //user_profile Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

	if(isset($_POST['submit']))
	{
		$role_name = $_REQUEST["role_name"];
		
		if (!empty($_POST['export'])){$export=1;}
		else{$export = 0;}

		if (!empty($_POST['data_delete'])){$data_delete=1;}
		else{$data_delete = 0;}

		if (!empty($_POST['user_profile'])){$user_profile=1;}
		else{$user_profile = 0;}

		if (!empty($_POST['roles_update'])){$roles_update=1;}
		else{$roles_update = 0;}

		if (!empty($_POST['roles_view'])){$roles_view=1;}
		else{$roles_view = 0;}
		
		if (!empty($_POST['data_update'])){$data_update=1;}
		else{$data_update = 0;}

		if (!empty($_POST['companylist'])){$companylist=1;}
		else{$companylist = 0;}

		if (!empty($_POST['agentlist'])){$agentlist=1;}
		else{$agentlist = 0;}
		
		if (!empty($_POST['insurerlist'])){$insurerlist=1;}
		else{$insurerlist = 0;}

		if (!empty($_POST['productionlist'])){$productionlist=1;}
		else{$productionlist = 0;}

		$sql = "INSERT INTO tblroles (`role_name`, `companylist`, `agentlist`,`insurerlist`, `export`,`user_profile`, `roles_update`, `roles_view`, `data_delete`, `productionlist`,data_update) 
		VALUES ('$role_name','$companylist','$agentlist','$insurerlist','$export','$user_profile','$roles_update','$roles_view','$data_delete','$productionlist','$data_update')";

		$result = mysql_query($sql);
		
		if($result == true) {
			echo "<script> 
			var a = 'Record Added Successfully';
			alert(a);
			</script>

			<script language='javascript' type='text/javascript'>
				window.location='./roles_view.php';
			 </script>";
		 } else {
			echo "<script> 
			var a = 'Record Added Failed!';
			alert(a);
			</script>

			<script language='javascript' type='text/javascript'>
				window.location='./roles_view.php';
			 </script>";
		 }
	}
?>

<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">

<script type="text/javascript">
$(document).ready(function () {
$("#clear").click(function(){
	$('#role_name').val("");
    });
    });
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('input[name="role_name"]').blur(function(){
        var txt = $(this);
        var updateid = $('#updateid').val();
        var role_name = txt.val();
        $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { role_name: role_name,updateid:updateid}
        }).done(function(res) {
            if (res == 1){
            	alert('Rolename already exist!')
                $('#role_name').val("");
            } else {
                return false;
            }
        });
    });
});
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9"  style="width:100%">
	<form method="post" action="" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Add Roles & Permisson</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:400px;width:100%">
		
		<div class="addrecord">
		
		<table>
		<tr>
				<td>
				<label style="width:100px;">Role Name *: </label>
				</td>
				<td>
				<input required style="width:200px;" type="text" id="role_name" name="role_name" value=""/> 
				</td>
			<tr><td>&nbsp;&nbsp;&nbsp;</td><td></td></tr>
		</table>	
		</br>
		<table style="width:100%">
			</tr>
				<tr>
				<td ><label style="width:100px;">Permission : </label></td>
				<td style="width:250px;">
				<input name="productionlist" type="checkbox" value="productionlist"> Production List
				</td>
				<td style="width:250px;">
				<input name="companylist" type="checkbox" value="companylist"> Companylist Master
				</td>
				<td style="width:250px;">
				<input name="agentlist" type="checkbox" value="agentlist"> Agentlist Master
				</td>
				<td style="width:250px;">
				<input name="insurerlist" type="checkbox" value="insurerlist"> Insurerlist Master
				</td>
				
				
				</tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td>
				<input name="export" type="checkbox" value="export"> Export 
				</td>
				<td>
				<input name="user_profile" type="checkbox" value="user_profile"> User Profile
				</td>
				<td>
				<input name="data_delete" type="checkbox" value="data_delete"> Delete
				</td>
				<td>
				<input name="roles_view" type="checkbox" value="roles_view"> Roles View
				</td>
				
				</tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td>
				<input name="roles_update" type="checkbox" value="roles_update"> Roles Update
				</td>
				<td>
				<input name="data_update" type="checkbox" value="data_update"> Data Update
				</td>
				<td>
				</td>
				<td>
				</td>
				<td>
				</td>
				</tr>
				</table>

			</br>
			</br>
		<table>

			</br>
			</br>
		
			<table>
			<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td><input style="width:100px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit"></td>
				<td>&nbsp;&nbsp;&nbsp;</td>
				<td><input style="width:100px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='roles_view.php';"></td>
			</tr>
			</table>		
		</div>
		</div>
	</div>
	</div>
	</div>
	</section>
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>