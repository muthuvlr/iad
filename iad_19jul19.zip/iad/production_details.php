<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("perpage.php");	
require_once("dbcontroller.php");

$db_handle = new DBController();
	
	$name_of_client = "";
	$customer_id = "";
	$premium_outstanding = "";
	$referral_name = "";
	$policy_type = "";
	$insurer = "";
	$no_of_workers = "";
	$agent_name = "";
	$submission_date_from = "";
	$submission_date_to = "";
	$sesDataUpdate = $_SESSION['SESSION_data_update'];
	$sesExport = $_SESSION['SESSION_export'];
	$dataDelete = $_SESSION['SESSION_data_delete'];
	$queryCondition = "";

	if(isset($_POST['bmail'])) {
		$multiId = implode($_POST["chkmail"], ",") ;
		if (empty($multiId)) {
			echo "<script> var a = 'Please select at least 1 checkbox for sending mail '; alert(a); </script>";
		} else {
			echo "<script language='javascript' type='text/javascript'> window.location='./debit_templete.php?mid=$multiId'; </script>";
		}
	}
	if(isset($_POST['search'])) {
		$arrCount = 0;
		foreach($_POST["search"] as $j=>$va){
			if(!empty($va)) {

				$queryCheck = array("submission_date_from","submission_date_to");
				if($j == "submission_date_from") {
					$submission_date_from = $va;
					$arrCount = $arrCount + 1;
				}
				if($j == "submission_date_to") {
					$submission_date_to = $va;
					$arrCount = $arrCount + 1;
				}
			}
		}

		foreach($_POST["search"] as $k=>$v){
			if(!empty($v)) {

				$queryCases = array("name_of_client","customer_id","premium_outstanding","policy_type","insurer","no_of_workers","agent_name","referral_name","submission_date_from","submission_date_to");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}
				switch($k) {
					case "name_of_client":
						$name_of_client = $v;
						$queryCondition .= "clist.company_name LIKE '%" . $v . "%'";
						break;
					case "customer_id":
						$customer_id = $v;
						$queryCondition .= "clist.customer_id LIKE '%" . $v . "%'";
						break;
					case "premium_outstanding":
						$premium_outstanding = $v;
						$queryCondition .= "pde.premium_outstanding > '" . $v . "'";
						break;
					case "referral_name":
						$referral_name = $v;
						$queryCondition .= "pde.referral_name LIKE '%" . $v . "%'";
						break;
					case "policy_type":
						$policy_type = $v;
						$queryCondition .= "pde.policy_type LIKE '%" . $v . "%'";
						break;
					case "insurer":
						$insurer = $v;
						$queryCondition .= "pde.insurer LIKE '%" . $v . "%'";
						break;
					case "no_of_workers":
						$no_of_workers = $v;
						$queryCondition .= "pde.no_of_workers LIKE '%" . $v . "%'";
						break;
					case "agent_name":
						$agent_name = $v;
						$queryCondition .= "alist.agent_name LIKE '%" . $v . "%'";
						break;
					case "submission_date_from":
						if($arrCount < 2) {
							$submission_date_from = $v;
							$queryCondition .= "pde.submission_date LIKE '%" . $v . "%'";
						}
						break;
					case "submission_date_to":
						if($arrCount < 2) {
							$submission_date_to = $v;
							$queryCondition .= "pde.submission_date LIKE '%" . $v . "%'";
						}
						break;
				}
				$_SESSION['SESSION_PD_name_of_client'] = $name_of_client;
				$_SESSION['SESSION_PD_customer_id'] = $customer_id;
				$_SESSION['SESSION_PD_premium_outstanding'] = $premium_outstanding;
				$_SESSION['SESSION_PD_referral_name'] = $referral_name;
				$_SESSION['SESSION_PD_no_of_workers'] = $no_of_workers;
				$_SESSION['SESSION_PD_agent_name'] = $agent_name;
				$_SESSION['SESSION_PD_submission_date_from'] = $submission_date_from;
				$_SESSION['SESSION_PD_submission_date_to'] = $submission_date_to;
				$_SESSION['SESSION_PD_insurer'] = $insurer;
				$_SESSION['SESSION_PD_policy_type'] = $policy_type;
				$_SESSION['SESSION_PD_production_export'] = '';
				$_SESSION['SESSION_PD_production_page'] = '';
			}
		}
	}
	if ($arrCount > 1) {
		$queryCondition =  str_replace('AND  AND', "AND", $queryCondition);
		$queryCondition =  str_replace('WHERE  AND', "WHERE", $queryCondition);
		$queryCondition .= "pde.submission_date between '" . $submission_date_from . "' AND '" .  $submission_date_to. "'";
	}
	$sql = "SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type, pde.insurer, pde.no_of_workers, pde.description, pde.premium, pde.premium_wgst, pde.commission1, pde.commission2,pde.agency_com, alist.agent_name, pde.agent_com, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.premium_paid_to_insurer, pde.premium_paid_by_client, pde.submission_date FROM production_details as pde
			INNER JOIN company_list as clist on clist.id = pde.company_id  
			INNER JOIN agent_list as alist on alist.id = pde.agent_id  
			LEFT JOIN tbllogin as login on login.id = pde.updated_by" . $queryCondition;
	$orderby = " GROUP BY pde.id ORDER BY id desc"; 
	$href = 'production_details.php';					

	if(isset($_GET["action"])){
		if($_GET["action"] == 'reset') {
			$_SESSION['SESSION_PD_brand_page'] = '';
			$_SESSION['SESSION_PD_name_of_client'] = '';
			$_SESSION['SESSION_PD_customer_id'] = '';
			$_SESSION['SESSION_PD_premium_outstanding'] = '';
			$_SESSION['SESSION_PD_referral_name'] = '';
			$_SESSION['SESSION_PD_no_of_workers'] = '';
			$_SESSION['SESSION_PD_agent_name'] = '';
			$_SESSION['SESSION_PD_submission_date_from'] = $submission_date_from;
			$_SESSION['SESSION_PD_submission_date_to'] = $submission_date_to;
			$_SESSION['SESSION_PD_insurer'] = '';
			$_SESSION['SESSION_PD_policy_type'] = '';
			$_SESSION['SESSION_PD_production_export'] = $sql;
		} else if ($_GET["action"] == 'bulkmail') {
			echo "ssssss";
			print_r($_GET);die;
		}
		
	}else if(!empty($_SESSION['SESSION_PD_production_export'])){
		$sql = $_SESSION['SESSION_PD_production_export']; 	
	}else{
		$_SESSION['SESSION_PD_production_export'] = $sql;
	}

	$perPage = 10; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
		$_SESSION['SESSION_PD_production_page'] = $page;
	} else {
		if(isset($_SESSION['SESSION_PD_production_page'])) {
			$page = $_SESSION['SESSION_PD_production_page'];
		}
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
	
	$result = $db_handle->runQuery($query);
	
	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}

	$name_of_client = $_SESSION['SESSION_PD_name_of_client'];
	$customer_id = $_SESSION['SESSION_PD_customer_id'];
	$premium_outstanding = $_SESSION['SESSION_PD_premium_outstanding'];
	$referral_name = $_SESSION['SESSION_PD_referral_name'];
	$no_of_workers = $_SESSION['SESSION_PD_no_of_workers'];
	$agent_name = $_SESSION['SESSION_PD_agent_name'];
	$submission_date_from = $_SESSION['SESSION_PD_submission_date_from'];
	$submission_date_to = $_SESSION['SESSION_PD_submission_date_to'];
	$insurer = $_SESSION['SESSION_PD_insurer'];
	$policy_type = $_SESSION['SESSION_PD_policy_type'];

?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>

<script type="text/javascript">
	 $(document).ready(function () {
			$('.chk_boxes').click(function() {
	        $('.chk_boxes1').prop('checked', this.checked);
	    });
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#date_received').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#submission_date_from').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#submission_date_to').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        });
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">
	<!-- Individual Page Widget-->
	<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Production Details - Send Bulk Mail</span>
	</div>
	<body>
    <div id="toys-grid">      
		<form name="frmEmailSearch" method="post" action="production_details.php">
			<div class="search-box" style="width:98%; height:40px;">
			<p class="p-tag">
			<input style="width:17%;" type="text" placeholder="NetPayable >" name="search[premium_outstanding]" value="<?php echo $premium_outstanding; ?>"	/>
			<input style="width:17%;" type="text" placeholder="Agent name" name="search[agent_name]" value="<?php echo $agent_name; ?>"	/>
			<input style="width:17%;" type="text" placeholder="Submission date from" id="submission_date_from" name="search[submission_date_from]" value="<?php echo $submission_date_from; ?>"	/>
			<input style="width:17%;" type="text" placeholder="Submission date to" id="submission_date_to" name="search[submission_date_to]" value="<?php echo $submission_date_to; ?>"	/>

			<input style="width:8%;" type="submit" name="go" class="btnSearch" value="Search...">
			<input style="width:8%;" name="reset" type="reset" class="btnSearch" value="Reset..." onclick="window.location='production_details.php?action=reset'">
			<input style="width:8%;" type="submit" name="bmail" class="btnSearch" value="Sendmail...">
			</p>
			</div>
			<div style="width:100%; height:500px; overflow:auto;">
			<table style="float:left;" class="table table-bordered">
        <thead>
			<tr>
				<th style="width:5%;"><strong>Sl.No</strong></th>
				<th style="width:20%;"><strong>Name of Client</strong></th>
			    <th style="width:15%;"><strong>Customer Id</strong></th>
				<th style="width:10%;"><strong>Policy Number</strong></th>
				<th style="width:10%;"><strong>Policy Type</strong></th>
				<th style="width:10%;"><strong>Insurer</strong></th>
				<th style="width:10%;"><strong>Agent Name</strong></th>
				<th style="width:10%;"><strong>Premium Paid by Client</strong></th>
				<th style="width:10%;"><strong>Premium Outstanding</strong></th>
				<th style="width:7%;"><strong>Bulk Email</strong> <input type="checkbox" class="chk_boxes" label="check all"  /></th>
			</tr>
				</thead>
				<tbody>
					<?php
					if(count($result)>0){
						foreach($result as $k=>$v) {
						if(is_numeric($k)) {
							$date_of_deployment = ($result[$k]["date_of_deployment"]>'2000-01-01') ? $result[$k]["date_of_deployment"] : '';
					?>
						<tr>
						<td><?php echo $start+$k+1; ?></td>
						<td><?php echo $result[$k]["name_of_client"]; ?></td>
						<td><?php echo $result[$k]["customer_id"]; ?></td>
						<td><?php echo $result[$k]["premium_outstanding"]; ?></td> 
						<td><?php echo $result[$k]["policy_type"]; ?></td> 
						<td><?php echo $result[$k]["insurer"]; ?></td> 
						<td><?php echo $result[$k]["agent_name"]; ?></td> 
						<td><?php echo $result[$k]["premium_paid_by_client"]; ?></td> 
						<td><?php echo $result[$k]["premium_outstanding"]; ?></td> 
						<td>
							<input type="checkbox" class="chk_boxes1" name ="chkmail[]" id="<?php echo $result[$k]["id"];?>" value="<?php echo $result[$k]["id"];?>"  />
						</a>
						</td>

						</tr>
						<?php
							}
						}
					}
					?>
				<tbody>
			</table>
			</div>
			<?php
			if(isset($result["perpage"])) { ?>
				<table>
				</br>
				<tr>
					<td colspan="14" align=right> <?php echo $result["perpage"]; ?></td>
				</tr>
				</table>
			<?php } ?>
			</form>	
		</div>
	</body>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
</section>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>