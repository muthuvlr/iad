<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("perpage.php");	
require_once("dbcontroller.php");

$db_handle = new DBController();
	
	$insurer_name = "";
	$abbreviation = "";
	$updated_by = "";
	$contact_number = "";
	$sesDataUpdate = $_SESSION['SESSION_data_update'];
	$sesExport = $_SESSION['SESSION_export'];
	$dataDelete = $_SESSION['SESSION_data_delete'];
	$queryCondition = "";
	if(isset($_POST['search'])) {
		foreach($_POST["search"] as $k=>$v){
			if(!empty($v)) {

				$queryCases = array("insurer_name","abbreviation");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}
				switch($k) {
					case "insurer_name":
						$insurer_name = $v;
						$queryCondition .= "insurer.insurer_name LIKE '%" . $v . "%'";
						break;
					case "abbreviation":
						$abbreviation = $v;
						$queryCondition .= "insurer.abbreviation LIKE '%" . $v . "%'";
						break;
				}
				$_SESSION['SESSION_insurer_EXPORT'] = '';
				$_SESSION['SESSION_insurer_page'] = '';
				$_SESSION['SESSION_insurer_name'] = $insurer_name;
				$_SESSION['SESSION_abbreviation'] = $abbreviation;
			}
		}
	}
	
	$sql = "SELECT insurer.id, insurer.insurer_name, insurer.abbreviation, insurer.updated_by, insurer.created_on FROM insurer_list as insurer 
			LEFT JOIN tbllogin as login on login.id = insurer.updated_by" . $queryCondition;
	$orderby = " GROUP BY insurer.id ORDER BY id desc"; 
	$href = 'insurer_view.php';					

	if(isset($_GET["action"])){
		$_SESSION['SESSION_insurer_page'] = '';
		$_SESSION['SESSION_insurer_name'] = '';
		$_SESSION['SESSION_abbreviation'] = '';
		$_SESSION['SESSION_insurer_EXPORT'] = $sql;
	}else if(!empty($_SESSION['SESSION_insurer_EXPORT'])){
		$sql = $_SESSION['SESSION_insurer_EXPORT']; 	
	}else{
		$_SESSION['SESSION_insurer_EXPORT'] = $sql;
	}

	$perPage = 10; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
		$_SESSION['SESSION_insurer_page'] = $page;
	} else {
		if(isset($_SESSION['SESSION_insurer_page'])) {
			$page = $_SESSION['SESSION_insurer_page'];
		}
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
	$result = $db_handle->runQuery($query);
	

	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}
	$insurer_name = $_SESSION['SESSION_insurer_name'];
	$abbreviation = $_SESSION['SESSION_abbreviation'];

?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
<script type="text/javascript">
$(document).ready(function () 
{
	$('.clsdelete').click(function()
	{
		var essay_id = $(this).attr('id');
		var x;
		if (confirm("Do you want to delete?") == true) 
		{
			$.ajax({
			  type : 'post',
			   url : 'insurer_delete.php?', // in here you should put your query 
			   data :{action:'delete',id:essay_id}, // here you pass your id via ajax .
			  
						 // in php you should use $_POST['post_id'] to get this value 
			success : function(r)
			   {
				  // now you can show output in your modal 
				  $('#mymodal').show();  // put your modal id 
				 $('.something').show().html(r);
			   }
			});

		} else 
		{
			//x = "You pressed Cancel!";
			//alert(x + essay_id);
		}
    });
});
</script>

<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">

	<!-- Individual Page Widget-->
	<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Insurer Listing</span>
	</div>
	<body>
		
    <div id="toys-grid">      
			<form name="frmSearch" method="post" action="insurer_view.php">
			
			<div class="search-box" style="width:98%; height:40px;">
			<p class="p-tag">
			<input style="width:19%;" type="text" placeholder="Insurer Name" name="search[insurer_name]" value="<?php echo $insurer_name; ?>"	/>
			<input style="width:19%;" type="text" placeholder="Abb" name="search[abbreviation]" value="<?php echo $abbreviation; ?>"	/>

			<input style="width:8%;" type="submit" name="go" class="btnSearch" value="Search..">
			<input style="width:8%;" name="reset" type="reset" class="btnSearch" value="Reset.." onclick="window.location='insurer_view.php?action=reset'">
			
			<?php if ($sesDataUpdate == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Addnew" onclick="window.location='insurer_edit.php'">
			<?php } 
			if ($sesExport == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Export" onclick="window.location='insurer_export.php'">
			<?php } ?>
			</p>
			</div>

			<div style="width:100%; height:500px; overflow:auto;">
			<table style="float:left;" class="table table-bordered">
        <thead>
			<tr>
				<th style="width:5%;"><strong>Sl.No</strong></th>
				<th style="width:10%;"><strong>Insurer Name</strong></th>
				<th style="width:10%;"><strong>Abb</strong></th>
				<?php 
				if ($sesDataUpdate == "1") {?>
				<th style="width:5%;"><strong>Edit</strong></th>
				<?php } if ($dataDelete == "1") { ?>
				<th style="width:5%;"><strong>Delete</strong></th>
				<?php } ?>				
			</tr>
				</thead>
				<tbody>
					<?php
					if(count($result)>0){
						foreach($result as $k=>$v) {
						if(is_numeric($k)) {
							
					?>
						<tr>
						<td><?php echo $start+$k+1; ?></td>
						<td><?php echo $result[$k]["insurer_name"]; ?></td> 
						<td><?php echo $result[$k]["abbreviation"]; ?></td> 
						
						<?php
						if ($sesDataUpdate == "1") {?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"];?>" class="abc" onclick="window.location.href = 'insurer_edit.php?id=' + <?php echo $result[$k]["id"];?>">
								<img id="eidtico" name="eidtico" src="img/edit-icon.png" class="utopia-widget-icon" >
								</a>
						</td>
						<?php } if ($dataDelete == "1") { ?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"]; ?>" class="clsdelete" >
									<img id="deleteico" name="deleteico" src="img/delete-icon.png" class="utopia-widget-icon"></a>
						</td>
						<?php } ?> 
						</tr>
						<?php
							}
						}
					}
					if(isset($result["perpage"])) {
					?>
					<tr>
					<td colspan="13" align=right> <?php echo $result["perpage"]; ?></td>
					</tr>
					<?php } ?>
				<tbody>
			</table>
			</div>
			</form>	
		</div>
	</body>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
</section>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>