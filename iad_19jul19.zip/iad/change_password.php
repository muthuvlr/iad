<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
/* Code */
	$user_id = $_SESSION['SESSION_USER_ID'];
	if(isset($_POST['submit']))
	{
		$password = $_POST['password'];
		$oldpassword = $_POST['oldpassword'];
		$conformpassword  = $_POST['conformpassword'];
		$oldpassword= $_POST['oldpassword'];
		//$oldpassword= crypt(strrev($_POST['oldpassword']),strrev('pwd321'));
		
		$res = mysql_query("SELECT * FROM tbllogin WHERE password='$oldpassword' and Id = $user_id");
		
		$num_rows = mysql_num_rows($res);
		if($num_rows >0)
		{
			if ($conformpassword==$password)
			{
				$password= $_POST['password'];
				//$password= crypt(strrev($_POST['password']),strrev('pwd321'));
				$query = mysql_query("UPDATE tbllogin SET password='$password' where id = $user_id");
				echo "<script> 
				var a = 'Password Successfully Changed!!';
				alert(a);
				</script>

				<script language='javascript' type='text/javascript'>
					window.location='./profile.php';
				 </script>";
			 }
			 else
			 {
			 echo "<script> 
				var a = 'Password and confirm password mismatch!';
				alert(a);
				</script>";
			 }
		 }
		 else
		 {
			echo "<script> 
			var a = 'Invalid Password! Can not update new password.';
			alert(a);
			</script>";
		 }
	}
?>
<script language="javascript">
function Validate()
{
	var password = $('#password').val();
    $pwdspacechk = password.search(" ");
	if($pwdspacechk > 0){
	  	alert("Don't allow space for password!");
		return false;
	}  
}
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9">
	
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Change Password</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace">
		<form method="post" action="" class="form-horizontal">
			<fieldset>
				<div class="control-group" >
				<label class="control-label" style="width:130px" for="input01" >Enter your Old password *</label>
				<div class="controls"><input style="width:200px" id="oldpassword" name="oldpassword" class="span12"  type="password" required></div>
				</div>
				
				<div class="control-group" >
				<label class="control-label" style="width:130px" for="input01" >Enter your New password *</label>
				<div class="controls"><input style="width:200px" id="password" name="password" class="span12"  type="password" required></div>
				</div>
				
				<div class="control-group" >
				<label class="control-label" style="width:130px" for="input01" >Enter your Confirm password *</label>
				<div class="controls"><input style="width:200px" id="conformpassword" name="conformpassword" class="span12"  type="password" required></div>
				</div>
				
				<div class="control-group">
				<div style="margin-left:160px;width:250px;">
				<input class="btn btn-primary span4" type="submit" id="submit" name="submit" value="Change">
				</div>
				<div style="margin-top:-28px;margin-left:250px;width:250px;">
				<input class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='profile.php';">
				</div>
				</div>
				
			</fieldset>
		</form><br/><br/>
	</div>
	</div>
	</div>
	</section>
	
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>

