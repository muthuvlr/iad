<?php 
error_reporting(0);
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

$agent_name = $_POST["agent_name"];
$agent_name = str_replace("'","\'",$agent_name);
$abb = $_POST["abb"];
$abb = str_replace("'","\'",$abb);
$cell_number = $_POST["cell_number"];
$email_id = $_POST["email_id"];
$date_joined = $_POST["date_joined"];

date_default_timezone_set("Asia/Kolkata");
$date_joined = date('Y-m-d H:i:s');
$active_status = 1;

$now = date('Y-m-d');

$userId = $_SESSION['SESSION_USER_ID'];
if(!empty($_GET["id"])) {
	if(!empty($_POST["submit"])) {

		$sqlQuery = "UPDATE agent_list set 
			agent_name = '".$agent_name."', 
			cell_number = '".$cell_number."', 
			abb = '".$abb."', 
			email_id = '".$email_id."', 
			date_joined = '".$date_joined."', 
			updated_on = '".$now."', 
			updated_by = '".$userId."'";

		$condtion = " WHERE  id=".$_GET['id'];
		$sqlQuery = $sqlQuery . $condtion; 

		$result = mysql_query($sqlQuery);
		if(!$result){
			$message = "Problem in Editing! Please Retry!";
		} else {
			if(strlen($name) == 0){
				echo "<script> var a = 'Update Successful'; alert(a); </script>";
			}
			echo "<script language='javascript' type='text/javascript'>window.location='./agent_view.php';</script>";
			//header("Location:agent_view.php");
		}
	}
	$result = $db_handle->runQuery("SELECT * FROM agent_list WHERE id='" . $_GET["id"] . "'");
}
else{
	if(!empty($_POST["submit"])) {

		$sqlQuery = "INSERT INTO agent_list(agent_name, cell_number, email_id, abb, date_joined,  created_on, created_by, updated_on, updated_by) 
		VALUES('".$agent_name."','".$cell_number."','".$email_id."','".$abb."','".$date_joined."','". $now."','".$userId."','".$now."','".$userId."')";

		$result = mysql_query($sqlQuery);
		if(!$result){
				$message="Problem in Adding to database. Please Retry.";
		} else {
			echo "<script language='javascript' type='text/javascript'>window.location='./agent_view.php';</script>";
		}
	}
}

?>	
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function () {
	$("#clear").click(function(){
		$('#agent_name').val("");
		$('#cell_number').val("");
		$('#abb').val("");
		$('#date_joined').val("");
		$('#email_id').val("");
	    });
    });
</script>
<script type="text/javascript">
	 $(document).ready(function () {
		//alert('hi');
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#date_joined1').datepicker({
            dateFormat: 'yy-mm-dd',
            maxDate: 0,
            weekStart: '0'
        });
        $("input[type='file']").change(function () {
        	var a = $(this).attr('id');
        	if(a=='file'){
        		lblfilename.innerHTML = this.value.replace(/C:\\fakepath\\/i, '');
        	}
		})
    });
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%">
<form action="" name="mform" method='post' enctype="multipart/form-data" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
		<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Add/Update Agent Details</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:400px;">
		<?php
		if(isset($_GET["id"]))
		{
			$agent_name = $result[0]["agent_name"];
			$cell_number = $result[0]["cell_number"];
			$abb = $result[0]["abb"];
			$date_joined = $result[0]["date_joined"]; 
			$email_id = $result[0]["email_id"];
			$updated_by = $result[0]["updated_by"];
		}
		?>
			<table>
			<tr>
				<td>
				<label style="width:150px;">Agent Name *: </label>
				</td>
				<td>
				<input type="hidden" readonly id="updateid" name="updateid" value="<?php echo $id;?>"/>
				<input required style="width:250px;" type="text" id="agent_name" name="agent_name" value="<?php echo $agent_name;?>"/>
				</td>
				<td>
				
				</td>
				<td>
				
				</td>
			</tr>
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td>
				<label>Abb : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="abb" name="abb" value="<?php echo htmlspecialchars($abb);?>"/>
				</td>
				<td>
				</td>
				<td>
				
				</td>
			</tr>
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td>
				<label>Cell Number : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="cell_number" name="cell_number" value="<?php echo $cell_number;?>"/>
				</td>
				<td>
				</td>
				<td>
				
				</td>
			</tr>
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td>
				<label>Email Id : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="email_id" name="email_id" value="<?php echo $email_id;?>"/>
				</td>
				<td>
				</td>
				<td>
				
				</td>
			</tr>
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td>
				<label style="width:140px;">Date Joined : </label>
				</td>
				<td>
					<input style="width:250px;background-color:#FFFFFF;" readonly type="text" id="date_joined" name="date_joined" value="<?php echo $date_joined;?>"/>
				</td>
				<td>
				
				</td>
				<td>
				</td>
			</tr>

			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td></td>
				<td>
				<table>
				<tr>
				<td><input style="width:80px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit" onclick="return Validate()"></td>
				<td><input style="width:80px;" class="btn btn-primary span4" id="clear" name="clear" type="button" value="Clear"></td>
				<td><input style="width:80px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='agent_view.php';"></td>
				</tr>
				</table>
				</td>
			</tr>
		</table>

	</div>
	</div>
	</div>
	</section>
	
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>