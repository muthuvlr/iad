<?php 
error_reporting(0);
	date_default_timezone_set("Asia/Bangkok");
    // set timeout period in seconds
    $inactive = 15 * 60;
    // check to see if $_SESSION['timeout'] is set
    if(isset($_SESSION['timeout']) ) 
	{
		$session_life = time() - $_SESSION['timeout'];
		if($session_life > $inactive)
		{ 
			session_destroy(); 
			echo "<script language='javascript' type='text/javascript'>window.location='./logout.php'; </script>";
			exit;
		}
    }
    $_SESSION['timeout'] = time();
	
?>