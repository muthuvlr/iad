<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
/* Code */
	$userId = $_SESSION['SESSION_USER_ID'];
	$role_id = $_SESSION['SESSION_role_id'];
	$process_type = $_SESSION['SESSION_process_type'];
	$user_name = $_SESSION['SESSION_USER_USERNAME'];

	$db_handle = new DBController();

	$sql = "SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type, pde.insurer, pde.no_of_workers, pde.description, pde.premium, pde.premium_wgst, pde.commission1, pde.commission2,pde.agency_com, alist.agent_name, pde.agent_com, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.premium_paid_to_insurer, pde.premium_paid_by_client, pde.submission_date FROM production_details as pde
			INNER JOIN company_list as clist on clist.id = pde.company_id  
			INNER JOIN agent_list as alist on alist.id = pde.agent_id  
			LEFT JOIN tbllogin as login on login.id = pde.updated_by ";
	$sql1 = $sql . " WHERE datediff(now(),date(pde.submission_date)) BETWEEN  45 AND 55";
	$sql2 = $sql . " WHERE datediff(now(),date(pde.submission_date)) BETWEEN  56 AND 90";
	$sql3 = $sql . " WHERE pde.submission_date < CURDATE() - INTERVAL 90 DAY";
	$result1 = $db_handle->runQuery($sql1);
	$result2 = $db_handle->runQuery($sql2);
	$result3 = $db_handle->runQuery($sql3);


?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">

<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%;">
	
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Dashboard</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="width:100%">
	<form action="" method='post' enctype="multipart/form-data" class="form-horizontal">
		<fieldset>
			<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
				<thead>
				<tr>
					<th style="text-align:center" width="15%"><strong>Name of Client</strong></th>
					<th style="text-align:center" width="15%"><strong>Policy Number</strong></th>
					<th style="text-align:center" width="15%"><strong>Agent Name</strong></th>
					<th style="text-align:center" width="15%"><strong>Premium Outstanding</strong></th>
				</tr>
				
				<?php
				if(count($result1)>0) { ?>
					<tr>
						<th colspan="4" style="text-align:center" width="100%"><strong>45 to 55 days</strong></th>
					</tr>
					</thead>
					<tr>
						<td colspan="4">
							<div style="width:100%; height:240px; overflow:auto;">
							<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
								<?php
								foreach($result1 as $k=>$v) {
								 ?>
							 		<tr>
										<td style="text-align:center" width="15%"><?php echo $result1[$k]["name_of_client"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result1[$k]["policy_number"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result1[$k]["agent_name"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result1[$k]["premium_outstanding"];?></td>
									</tr>
								<?php
								}  ?>
							</table>
							</div>
						</td>
					</tr>
				<?php
				} ?>
			</table>
		</fieldset>
		<fieldset>
			<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
				<thead>
				
				<?php
				if(count($result2)>0) { ?>
					<tr>
						<th colspan="4" style="text-align:center" width="100%"><strong>56 to 90 days</strong></th>
					</tr>
					</thead>
					<tr>
						<td colspan="4">
							<div style="width:100%; height:240px; overflow:auto;">
							<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
								<?php
								foreach($result2 as $k=>$v) {
								 ?>
							 		<tr>
										<td style="text-align:center" width="15%"><?php echo $result2[$k]["name_of_client"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result2[$k]["policy_number"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result2[$k]["agent_name"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result2[$k]["premium_outstanding"];?></td>
									</tr>
								<?php
								}  ?>
							</table>
							</div>
						</td>
					</tr>
				<?php
				} ?>
			</table>
			
		</fieldset>
		<fieldset>
			<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
				<thead>
				<?php
				if(count($result3)>0) { ?>
					<tr>
						<th colspan="4" style="text-align:center" width="100%"><strong>90 days above</strong></th>
					</tr>
					</thead>
					<tr>
						<td colspan="4">
							<div style="width:100%; height:240px; overflow:auto;">
							<table style="float:left;" class="table table-bordered" id="report2" cellpadding="0">
								<?php
								foreach($result3 as $k=>$v) {
								 ?>
							 		<tr>
										<td style="text-align:center" width="15%"><?php echo $result3[$k]["name_of_client"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result3[$k]["policy_number"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result3[$k]["agent_name"];?></td>
										<td style="text-align:center" width="15%"><?php echo $result3[$k]["premium_outstanding"];?></td>
									</tr>
								<?php
								}  ?>
							</table>
							</div>
						</td>
					</tr>
				<?php
				} ?>
			</table>
		</fieldset>

	</form>
		
	</div>
	</div>
	</div>
	</section>
	
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>

