<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>MaraiCar Agency Production </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="theemio">
<link rel="shortcut icon" href="img/logo.png" />
<link class="theme-css" href="css/utopia-white3a1a.css?v99" rel="stylesheet">
<link href="css/utopia-responsive.css" rel="stylesheet">
<link href="css/ui-lightness/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="css/weather.css" rel="stylesheet" type="text/css"/>
<link href="css/gallery/modal.css" rel="stylesheet">
<link href="css/validationEngine.jquery.css" rel="stylesheet" type="text/css">
<link href="css/chosen.css" media="screen" rel="stylesheet" type="text/css"/>
<link href="css/ie.css" rel="stylesheet">
<link href="css/queryLoader.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.cookie.js"></script>
	<script>
	if($.cookie("css")){$('link[href*="utopia-white.css"]').attr("href",$.cookie("css"));$('link[href*="utopia-dark.css"]').attr("href",$.cookie("css"))}/*$(document).ready(function(){$(".theme-changer a").live("click",function(){$('link[href*="utopia-white.css"]').attr("href",$(this).attr("rel"));$('link[href*="utopia-dark.css"]').attr("href",$(this).attr("rel"));$.cookie("css",$(this).attr("rel"),{expires:365,path:"/"});return false})});*/
	</script>
	
<script type="text/javascript">
$(document).ready(function () {
$("#utopia-widget").click(function(){
	$(".menu1").show();
    });
    });
</script>
<script type="text/javascript">
$(document).ready(function () {
$("#menu3").click(function(){
	$(".menu2").show();
    });
    });
</script>
<script type="text/javascript">
$(document).ready(function () {
	$(".menu11").hide();
	$(".menu22").hide();
    });
</script>
<script type="text/javascript">
	$(".menu11").hide();
	$(".menu22").hide();
</script>
		
</head>
<body>

<div class="container-fluid">
	<div class="row-fluid">
		<div class="span12">
		<div class="header-top" style="height:50px;" >
		<a href="dashboard.php" class="utopia-logo"><img style="height:100%;" alt="Catalog Management Software" src="img/logo.png"></a>
		<div class="header-wrapper" >
			<div class="header-right">
			<div class="header-divider" style="height:50px;">&nbsp;</div>
			<div class="user-panel header-divider">
			<div class="user-info" style="height:18px;">
			
			<img src="img/icons/user.png" alt=""><b><a href="#"><?php echo $_SESSION['SESSION_FIRST_NAME'];?></a></b>
			
			</div>
				<div class="user-dropbox">
				<ul>
				<li class="user"><a href="profile.php">Profile</a></li>
				<li class="logout"><a href="logout.php">Logout</a></li>
				</ul>
				</div>
			</div>
			</div>
		</div>
		</div>
		</div>
	</div>
	
<div class="row-fluid">
<div class="span2 sidebar-container">
<div class="sidebar">
<div class="navbar sidebar-toggle">
<div class="container">
<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a>
</div>
</div>
<?php 

$sesRoleName = $_SESSION['SESSION_role_name'];
$sesExport = $_SESSION['SESSION_export'];
$sesDataDelete = $_SESSION['SESSION_data_delete'];
$sesUserProfile = $_SESSION['SESSION_user_profile'];
$sesRolesUpdate = $_SESSION['SESSION_roles_update'];
$sesRolesView = $_SESSION['SESSION_roles_view'];
$sesCompanyList = $_SESSION['SESSION_companylist'];
$sesAgentList = $_SESSION['SESSION_agentlist'];
$sesInsurerList = $_SESSION['SESSION_insurerlist'];
$sesProductionList = $_SESSION['SESSION_productionlist'];

$sesCrVersion = $_SESSION['SESSION_CR_VERSION'];

//date_default_timezone_set("Asia/Bangkok");
//date_default_timezone_set('GMT'); //UTC,
//date_default_timezone_set("GMT+05:30");

date_default_timezone_set("Asia/Kolkata");

/*echo date_default_timezone_get();
print date("m/d/y G.i:s<br>", time()); */

?>
<div class="nav-collapse collapse leftmenu">
	<ul>
		<li class="current">
			<a class="dashboard smronju" href="dashboard.php" title="Dashboard"><span><b>Dashboard</b> v.<?php echo $sesCrVersion;?></span>
			</a>
		</li>
		<?php if ($sesProductionList == "1") {?>
		<li>
			<a class="list" href="debit_note.php" title="Debit Note"><span>Debit Note</span></a>
<!--			<a class="list" href="production_view.php" title="Production Details"><span>Production Details</span></a>-->
			<a class="list" href="production_inline.php" title="Production Inline"><span>Production Inline</span></a>
			<a class="list" href="production_details.php" title="Send Bulk Email"><span>Send Bulk Email</span></a>
		</li>
		<?php } ?>
		</br>
		<section class="utopia-widget">
			<div class="utopia-widget-title">
				<img class="utopia-widget-icon" src="img/icons/arrow_down2.png" style="vertical-align:text-bottom;;">
				<span>Listings<span>
			</div>
			<div class="menu1">
				<div class="span12" style="margin-left:0px;">
					<?php if ($sesCompanyList == "1") {?>
					<li><a class="list" href="company_view.php" title="Company Listing"><span>Company Listing</span></a></li>
					<?php }
					if ($sesAgentList == "1") {?>
					<li><a class="list" href="agent_view.php" title="Agent Listing"><span>Agent Listing</span></a></li>
					<?php } 
					if ($sesInsurerList == "1") {?>
					<li><a class="list" href="insurer_view.php" title="Agent Listing"><span>Insurer Listing</span></a></li>
					<?php } ?>
					</br>
				</div>
				
			</div>
		</section>

		<div class="row-fluid">
			<div class="span12">
				<section class="utopia-widget">
					<div class="utopia-widget-title">
						<img class="utopia-widget-icon" src="img/icons/arrow_down2.png" style="vertical-align:text-bottom;;">
						<span>Users<span>
					</div>
					<div class="menu1">
						<div class="span12" style="margin-left:0px;">
						<?php if ($sesUserProfile == "1") {?>
								<li><a class="list" href="user.php" title="Add User"><span>User Profile</span></a></li>
							<?php } 
							if ($sesRolesView == "1") {?>
								<li><a class="list" href="roles_view.php" title="Add Roles"><span>Roles & Permission</span></a></li>
							<?php  } ?>	
							
						</div>
					</div>
				</section>
			</div>
		</div>
	</ul>
</div>
</div>
</div>