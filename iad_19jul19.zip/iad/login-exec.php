<?php

	ini_set( 'session.cookie_httponly', 1 );
	//Start session
	session_start();
	
	//Include database connection details
	require_once('dbcontroller.php');
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE,$link);
	if(!$db) {
		die("Unable to select database");
	}
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	//Input Validations
	if($username == '') {
		$errmsg_arr[] = 'Login ID missing';
		$errflag = true;
	}
	if($password == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
	}
	
	//If there are input validations, redirect back to the login form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: login-form.php");
		exit();
	}
	//$password= crypt(strrev($_POST['password']),strrev('pwd321'));
	//Create query
	$qry="SELECT * FROM tbllogin WHERE user_name='$username' AND password=BINARY '$password' and active = 1";
	$result= mysql_query($qry);

	if($result) {
		if(mysql_num_rows($result) == 1) {
			//Login Successful
			session_regenerate_id();
			$_SESSION['SESSION_CR_VERSION'] = CR_VERSION;
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESSION_USER_ID'] = $member['Id'];
			$_SESSION['SESSION_FIRST_NAME'] = $member['first_name'];
			$_SESSION['SESSION_LAST_NAME'] = $member['last_name'];
			$_SESSION['SESSION_USER_ROLE'] = $member['user_level'];
			$_SESSION['SESSION_USER_SHORTNAME'] = $member['short_name'];
			$_SESSION['SESSION_USER_USERNAME'] = $member['user_name'];
			$_SESSION['SESSION_USER_EMAILID'] = $member['email_id'];
			
			$sql="SELECT * FROM tblroles WHERE role_name='".$member['user_level']."'";
	
			$result = mysql_query($sql);
			$numrows = mysql_num_rows($result);

			if ($numrows > 0)
			{	
				$row = mysql_fetch_array($result);
				$_SESSION['SESSION_role_name'] = $row['role_name'];
				$_SESSION['SESSION_role_id'] = $row['id'];
				$_SESSION['SESSION_export'] = $row['export'];
				$_SESSION['SESSION_data_delete'] = $row['data_delete'];
				$_SESSION['SESSION_user_profile'] = $row['user_profile'];
				$_SESSION['SESSION_roles_update'] = $row['roles_update'];
				$_SESSION['SESSION_roles_view'] = $row['roles_view'];
				$_SESSION['SESSION_data_update'] = $row['data_update'];
				$_SESSION['SESSION_companylist'] = $row['companylist'];
				$_SESSION['SESSION_agentlist'] = $row['agentlist'];
				$_SESSION['SESSION_insurerlist'] = $row['insurerlist'];
				$_SESSION['SESSION_productionlist'] = $row['productionlist'];
			}
			session_write_close();
			header("location: dashboard.php");
			exit();
		}else {
			//Login failed
			//header("location: login-failed.php");
			$qry1 = "SELECT * FROM tbllogin WHERE user_name='$username' AND password=BINARY'$password'";
			$rst = mysql_query($qry1);
			if($rst) {
				if(mysql_num_rows($rst) == 1) {
				echo "<script> var a = 'Your account has been made inactive. Kindly contact admin.'; alert(a); </script>
					<script language='javascript' type='text/javascript'>
						window.location='./index.php'; </script>";
				}
				else{
					echo "<script> var a = 'Login Failed! Invalid Username or Password'; alert(a); </script>
						<script language='javascript' type='text/javascript'>
							window.location='./index.php'; </script>";
				}
			}			
		//exit();	
			
		}
	}else {
		die("Query failed");
	}
?>