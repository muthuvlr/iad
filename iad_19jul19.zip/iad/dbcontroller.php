<?php
require_once('config.php');
$connect = mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Connection Error: " . mysql_error()); 
$database = mysql_select_db(DB_DATABASE,$connect) or die("Error conecting to db."); 
	
class DBController {
	
	private $host = DB_HOST;
	private $user = DB_USER;
	private $password = DB_PASSWORD;
	private $database = DB_DATABASE;
	
	
	function __construct() {
		$conn = $this->connectDB();
		if(!empty($conn)) {
			$this->selectDB($conn);
		}
	}
	
	function connectDB() {
		$conn = mysql_connect($this->host,$this->user,$this->password);
		return $conn;
	}
	
	function selectDB($conn) {
		mysql_select_db($this->database,$conn);
	}
	
	function runQuery($query) {
		$result = mysql_query($query);
		while($row=mysql_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysql_query($query);
		$rowcount = mysql_num_rows($result);
		return $rowcount;	
	}

	function executeUpdate($query) {
        $result = mysql_query($query);        
		return $result;		
    }
}
?>