<?php
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

if(!empty($_REQUEST["id"])) {
	$result = mysql_query("DELETE FROM company_list WHERE id=".$_REQUEST["id"]);
	if(!empty($result)){
		echo "<script language='javascript' type='text/javascript'> window.location='./company_view.php'; </script>";
	}
}
?>

