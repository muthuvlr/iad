<?php 
error_reporting(0);
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

$insurer_name = $_POST["insurer_name"];
$insurer_name = str_replace("'","\'",$insurer_name);
$abbreviation = $_POST["abbreviation"];
$abbreviation = str_replace("'","\'",$abbreviation);

$active_status = 1;

$now = date('Y-m-d');
$userId = $_SESSION['SESSION_USER_ID'];
if(!empty($_GET["id"])) {
	if(!empty($_POST["submit"])) {

		$sqlQuery = "UPDATE insurer_list set 
			insurer_name = '".$insurer_name."', 
			abbreviation = '".$abbreviation."', 
			updated_on = '".$now."', 
			updated_by = '".$userId."'";

		$condtion = " WHERE  id=".$_GET['id'];
		$sqlQuery = $sqlQuery . $condtion; 

		$result = mysql_query($sqlQuery);
		if(!$result){
			$message = "Problem in Editing! Please Retry!";
		} else {
			if(strlen($name) == 0){
				echo "<script> var a = 'Update Successful'; alert(a); </script>";
			}
			echo "<script language='javascript' type='text/javascript'>window.location='./insurer_view.php';</script>";
			//header("Location:insurer_view.php");
		}
	}
	$result = $db_handle->runQuery("SELECT * FROM insurer_list WHERE id='" . $_GET["id"] . "'");
}
else{
	if(!empty($_POST["submit"])) {
//print_r($_POST);
		$sqlQuery = "INSERT INTO insurer_list(insurer_name, abbreviation,  created_on, created_by, updated_on, updated_by) 
		VALUES('".$insurer_name."','".$abbreviation."','". $now."','".$userId."','".$now."','".$userId."')";

		$result = mysql_query($sqlQuery);
		if(!$result){
				$message="Problem in Adding to database. Please Retry.";
		} else {
			echo "<script language='javascript' type='text/javascript'>window.location='./insurer_view.php';</script>";
		}
	}
}

?>	
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function () {
	$("#clear").click(function(){
		$('#insurer_name').val("");
		$('#abbreviation').val("");
		});
    });
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%">
<form action="" name="mform" method='post' enctype="multipart/form-data" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
		<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Add/Update Insurer Details</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:400px;">
		<?php
		if(isset($_GET["id"]))
		{
			$insurer_name = $result[0]["insurer_name"];
			$abbreviation = $result[0]["abbreviation"];
			$updated_by = $result[0]["updated_by"];
		}
		?>
			<table>
			<tr>
				<td>
				<label style="width:150px;">Insurer Name *: </label>
				</td>
				<td>
				<input type="hidden" readonly id="updateid" name="updateid" value="<?php echo $id;?>"/>
				<input required style="width:250px;" type="text" id="insurer_name" name="insurer_name" value="<?php echo $insurer_name;?>"/>
				</td>
				<td>
				
				</td>
				<td>
				
				</td>
			</tr>
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td>
				<label>Abb : </label>
				</td>
				<td>
				<input style="width:250px;" required type="text" id="abbreviation" name="abbreviation" value="<?php echo htmlspecialchars($abbreviation);?>"/>
				</td>
				<td>
				</td>
				<td>
				
				</td>
			</tr>
			
			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td></tr>
			<tr>
				<td></td>
				<td>
				<table>
				<tr>
				<td><input style="width:80px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit"></td>
				<td><input style="width:80px;" class="btn btn-primary span4" id="clear" name="clear" type="button" value="Clear"></td>
				<td><input style="width:80px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='insurer_view.php';"></td>
				</tr>
				</table>
				</td>
			</tr>
		</table>

	</div>
	</div>
	</div>
	</section>
	
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>