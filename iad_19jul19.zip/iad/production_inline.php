<?php
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("perpage.php");	
require_once("dbcontroller.php");

$db_handle = new DBController();

$name_of_client = "";
$customer_id = "";
$policy_number = "";
$referral_name = "";
$policy_type = "";
$insurer = "";
$no_of_workers = "";
$agent_name = "";
$submission_date_from = "";
$submission_date_to = "";
$net_payable_from = "";
$net_payable_to = "";
$sesDataUpdate = $_SESSION['SESSION_data_update'];
$sesExport = $_SESSION['SESSION_export'];
$dataDelete = $_SESSION['SESSION_data_delete'];
$queryCondition = "";

if(isset($_POST['search'])) {
	$arrCount = 0;
	$arrPayee = 0;
	foreach($_POST["search"] as $j=>$va){
		if(!empty($va)) {

			$queryCheck = array("submission_date_from","submission_date_to");
			if($j == "submission_date_from") {
				$submission_date_from = $va;
				$arrCount = $arrCount + 1;
			}
			if($j == "submission_date_to") {
				$submission_date_to = $va;
				$arrCount = $arrCount + 1;
			}
		}
	}
	if ($_POST["search"]['net_payable_from'] >= '0') {
		$net_payable_from = $_POST["search"]['net_payable_from'];
		$arrPayee = $arrPayee + 1;
	}
	if ($_POST["search"]['net_payable_to'] >= '0') {
		$net_payable_to = $_POST["search"]['net_payable_to'];
		$arrPayee = $arrPayee + 1;
	}
	foreach($_POST["search"] as $k=>$v){
		if(!empty($v) || $v >= '0') {

			$queryCases = array("name_of_client","customer_id","policy_number","policy_type","insurer","no_of_workers","agent_name","referral_name","submission_date_from","submission_date_to","net_payable_from","net_payable_to");
			if(in_array($k,$queryCases)) {
				if(!empty($queryCondition)) {
					$queryCondition .= " AND ";
				} else {
					$queryCondition .= " WHERE ";
				}
			}
			switch($k) {
				case "name_of_client":
					$name_of_client = $v;
					$queryCondition .= "clist.company_name LIKE '%" . $v . "%'";
					break;
				case "customer_id":
					$customer_id = $v;
					$queryCondition .= "clist.customer_id LIKE '%" . $v . "%'";
					break;
				case "policy_number":
					$policy_number = $v;
					$queryCondition .= "pde.policy_number LIKE '%" . $v . "%'";
					break;
				case "referral_name":
					$referral_name = $v;
					$queryCondition .= "pde.referral_name LIKE '%" . $v . "%'";
					break;
				case "policy_type":
					$policy_type = $v;
					$queryCondition .= "pde.policy_type LIKE '%" . $v . "%'";
					break;
				case "insurer":
					$insurer = $v;
					$queryCondition .= "ilist.abbreviation LIKE '%" . $v . "%'";
					break;
				case "no_of_workers":
					$no_of_workers = $v;
					$queryCondition .= "pde.no_of_workers LIKE '%" . $v . "%'";
					break;
				case "agent_name":
					$agent_name = $v;
					$queryCondition .= "alist.agent_name LIKE '%" . $v . "%'";
					break;
				case "submission_date_from":
					if($arrCount < 2) {
						$submission_date_from = $v;
						$queryCondition .= "pde.submission_date LIKE '%" . $v . "%'";
					}
					break;
				case "submission_date_to":
					if($arrCount < 2) {
						$submission_date_to = $v;
						$queryCondition .= "pde.submission_date LIKE '%" . $v . "%'";
					}
					break;
				case "net_payable_from":
					if($arrPayee < 2) {
						$net_payable_from = $v;
						$queryCondition .= "pde.premium_outstanding = '" . $v . "'";
					}
					break;
				case "net_payable_to":
					if($arrPayee < 2) {
						$net_payable_to = $v;
						$queryCondition .= "pde.premium_outstanding = '" . $v . "'";
					}
					break;
			}
			$_SESSION['SESSION_PI_name_of_client'] = $name_of_client;
			$_SESSION['SESSION_PI_customer_id'] = $customer_id;
			$_SESSION['SESSION_PI_policy_number'] = $policy_number;
			$_SESSION['SESSION_PI_referral_name'] = $referral_name;
			$_SESSION['SESSION_PI_no_of_workers'] = $no_of_workers;
			$_SESSION['SESSION_PI_agent_name'] = $agent_name;
			$_SESSION['SESSION_PI_submission_date_from'] = $submission_date_from;
			$_SESSION['SESSION_PI_submission_date_to'] = $submission_date_to;
			$_SESSION['SESSION_PI_insurer'] = $insurer;
			$_SESSION['SESSION_PI_policy_type'] = $policy_type;
			$_SESSION['SESSION_PI_net_payable_from'] = $net_payable_from;
			$_SESSION['SESSION_PI_net_payable_to'] = $net_payable_to;
			$_SESSION['SESSION_PI_production_export'] = '';
			$_SESSION['SESSION_PI_production_page'] = '';
		}
	}
}
if ($arrCount > 1) {
	$queryCondition =  str_replace('AND  AND', "AND", $queryCondition);
	$queryCondition =  str_replace('WHERE  AND', "WHERE", $queryCondition);
	$queryCondition .= "pde.submission_date between '" . $submission_date_from . "' AND '" .  $submission_date_to. "'";
}

if ($arrPayee > 1) {
	$queryCondition =  str_replace('AND  AND', "AND", $queryCondition);
	$queryCondition =  str_replace('WHERE  AND', "WHERE", $queryCondition);
	$queryCondition .= " AND pde.premium_outstanding between '" . $net_payable_from . "' AND '" .  $net_payable_to. "'";
	$queryCondition =  str_replace('WHERE  AND', "WHERE", $queryCondition);
}

$sql = "SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type, pde.policy_duration, ilist.abbreviation, pde.no_of_workers, pde.description, pde.premium, pde.gst, pde.premium_wgst, pde.commission1, pde.commission2,pde.agency_com, alist.abb, pde.agent_com, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.dn_premium, pde.premium_paid_to_insurer, pde.premium_paid_by_client, pde.submission_date,pde.com_paid_to_agent_date,pde.premium_paid_to_insurer_date,pde.remarks FROM production_details as pde
		INNER JOIN company_list as clist on clist.id = pde.company_id  
		INNER JOIN agent_list as alist on alist.id = pde.agent_id 
		LEFT JOIN insurer_list as ilist on ilist.id = pde.insurer		
		LEFT JOIN tbllogin as login on login.id = pde.updated_by" . $queryCondition;
$orderby = " GROUP BY pde.id ORDER BY id desc"; 
$href = 'production_inline.php';					

if(isset($_GET["action"])){
	$_SESSION['SESSION_PI_brand_page'] = '';
	$_SESSION['SESSION_PI_name_of_client'] = '';
	$_SESSION['SESSION_PI_customer_id'] = '';
	$_SESSION['SESSION_PI_policy_number'] = '';
	$_SESSION['SESSION_PI_referral_name'] = '';
	$_SESSION['SESSION_PI_no_of_workers'] = '';
	$_SESSION['SESSION_PI_agent_name'] = '';
	$_SESSION['SESSION_PI_submission_date_from'] = $submission_date_from;
	$_SESSION['SESSION_PI_submission_date_to'] = $submission_date_to;
	$_SESSION['SESSION_PI_insurer'] = '';
	$_SESSION['SESSION_PI_policy_type'] = '';
	$_SESSION['SESSION_PI_PI_net_payable_from'] = '';
	$_SESSION['SESSION_PI_net_payable_to'] ='';
	$_SESSION['SESSION_PI_production_export'] = $sql;
}else if(!empty($_SESSION['SESSION_PI_production_export'])){
	$sql = $_SESSION['SESSION_PI_production_export']; 	
}else{
	$_SESSION['SESSION_PI_production_export'] = $sql;
}

$perPage = 10; 
$page = 1;
if(isset($_POST['page'])){
	$page = $_POST['page'];
	$_SESSION['SESSION_PI_production_page'] = $page;
} else {
	if(isset($_SESSION['SESSION_PI_production_page'])) {
		$page = $_SESSION['SESSION_PI_production_page'];
	}
}
$start = ($page-1)*$perPage;
if($start < 0) $start = 0;
	
$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
$result = $db_handle->runQuery($query);

if(!empty($result)) {
	$result["perpage"] = showperpage($sql, $perPage, $href);
}

$name_of_client = $_SESSION['SESSION_PI_name_of_client'];
$customer_id = $_SESSION['SESSION_PI_customer_id'];
$policy_number = $_SESSION['SESSION_PI_policy_number'];
$referral_name = $_SESSION['SESSION_PI_referral_name'];
$no_of_workers = $_SESSION['SESSION_no_of_workers'];
$agent_name = $_SESSION['SESSION_PI_agent_name'];
$submission_date_from = $_SESSION['SESSION_PI_submission_date_from'];
$submission_date_to = $_SESSION['SESSION_PI_submission_date_to'];
$net_payable_from = $_SESSION['SESSION_PI_net_payable_from'];
$net_payable_to = $_SESSION['SESSION_PI_net_payable_to'];
$insurer = $_SESSION['SESSION_PI_insurer'];
$policy_type = $_SESSION['SESSION_PI_policy_type'];

?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
<script type="text/javascript">
$(document).ready(function () 
{
	$('.clsdelete').click(function()
	{
		var essay_id = $(this).attr('id');

		var x;
		if (confirm("Do you want to delete?") == true) 
		{
			$.ajax({
			  type : 'post',
			   url : 'production_delete.php?', // in here you should put your query 
			   data :{action:'delete',id:essay_id}, // here you pass your id via ajax .
			  
						 // in php you should use $_POST['post_id'] to get this value 
			success : function(r)
			   {
				  // now you can show output in your modal 
				  $('#mymodal').show();  // put your modal id 
				 $('.something').show().html(r);
			   }
			});

		} else 
		{
			//x = "You pressed Cancel!";
			//alert(x + essay_id);
		}
    });
});
</script>
<script type="text/javascript">
	 $(document).ready(function () {
		//alert('hi');
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#date_received').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#submission_date_from').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#submission_date_to').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        });
</script>

<style>
   .descr,.descr1{
    width:100px;
    display:inline-block;
    height: 30px;   
   overflow:hidden;
       text-align: center;
       
    }
    
/*
    .client{
        width:300px; !important
    }
*/
    
		body{width:100%;}
			.current-row{background-color:#B24926;color:#FFF;}
			.current-col{background-color:#1b1b1b;color:#FFF;}
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #f5f5f5;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;}
			.tbl-qa .table-row td {padding:10px;background-color: #FDFDFD;}
		</style>
		<script src="js/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background","#FFF");
            
               $('.descr').click(function(e) {
    e.stopPropagation();
    $('.descr').css({
        
        'overflow': 'auto',
        'width':'300px',
         'display':'inline-block',
        
    })
});
$('.descr1').click(function(e) {
    e.stopPropagation();
    $('.descr1').css({
        
        'overflow': 'auto',
        'width':'300px',
         'display':'inline-block',
        
    })
});
		} 
		
         

$(document).click(function() {
    $('.descr').css({
        'height': '30px', 
        'overflow':'hidden',
        'width':'100px'
    });
	$('.descr1').css({
        'height': '30px', 
        'overflow':'hidden',
        'width':'100px'
    })
})
            
            
		function saveToDatabase(editableObj,column,id) {
			
			$(editableObj).css("background","#FFF url(img/loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					console.log(data);
					$(editableObj).css("background","#FDFDFD");
				}        
		   });
		}
</script>

<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">
<!-- Individual Page Widget-->
<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Production Inline</span>
	</div>
	<body>
    <div id="toys-grid">      
		<form name="frmSearch" method="post" action="production_inline.php">
			<div class="search-box" style="width:98%; height:74px;">
			<p class="p-tag">
			<input style="width:13%;" type="text" placeholder="Name of client" name="search[name_of_client]" value="<?php echo $name_of_client; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Customer id" name="search[customer_id]" value="<?php echo $customer_id; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Policy number" name="search[policy_number]" value="<?php echo $policy_number; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Referral name" name="search[referral_name]" value="<?php echo $referral_name; ?>"	/>
			<input style="width:13%;" type="text" placeholder="No of workers" id="no_of_workers"  name="search[no_of_workers]" value="<?php echo $no_of_workers; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Agent name" name="search[agent_name]" value="<?php echo $agent_name; ?>"	/>

			<input style="width:7%;" type="submit" name="go" class="btnSearch" value="Search..">
			<input style="width:7%;" name="reset" type="reset" class="btnSearch" value="Reset.." onclick="window.location='production_inline.php?action=reset'">
			
			<input style="width:13%;" type="text" placeholder="Insurer" name="search[insurer]" value="<?php echo $insurer; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Policy type" name="search[policy_type]" value="<?php echo $policy_type; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Submission date from" id="submission_date_from" name="search[submission_date_from]" value="<?php echo $submission_date_from; ?>"	/>
			<input style="width:13%;" type="text" placeholder="Submission date to" id="submission_date_to" name="search[submission_date_to]" value="<?php echo $submission_date_to; ?>"	/>
			<input style="width:13%;" type="text" id="net_payable_from" placeholder="Net payable from"  name="search[net_payable_from]" value="<?php echo $net_payable_from; ?>" />
			<input style="width:13%;" type="text" id="net_payable_to" placeholder="Net payable to" name="search[net_payable_to]" value="<?php echo $net_payable_to; ?>" />

			<?php if ($sesDataUpdate == "1") {?>
			<input style="width:7%;" type="reset" class="btnSearch" value="Addnew" onclick="window.location='production_edit.php'">
			<?php } 
			if ($sesExport == "1") {?>
			<input style="width:7%;" type="reset" class="btnSearch" value="Export" onclick="window.location='production_export.php'">
			<?php } ?>
			</p>
			</div>

		<div style="width:100%; height:550px; overflow:auto;">
		<table style="float:left;" class="table table-bordered">
        <thead>
			<tr>
				<th style="width:5%;"><strong>Sl.No</strong></th>
				<th style="width:10%;"><strong>Submission Date</strong></th>
				<th style="width:20%;"><strong>Name of Client</strong></th>
			    <th style="width:15%;"><strong>Customer Id</strong></th>
				<th style="width:10%;"><strong>Policy Number</strong></th>
				<th style="width:10%;"><strong>Policy Type</strong></th>
				<!--<th style="width:10%;"><strong>Policy Duration</strong></th>-->
				<th style="width:10%;"><strong>Insurer</strong></th>
				<th style="width:10%;"><strong>No of workers</strong></th>
				<th style="width:10%;"><strong>Description</strong></th>
				<th style="width:10%;"><strong>Premium $</strong></th>
				<!--<th style="width:10%;"><strong>Gst</strong></th>-->
				<th style="width:10%;"><strong>Premium Wgst $</strong></th>
				<th style="width:10%;"><strong>DN Premium $</strong></th>
				<th style="width:10%;"><strong>Commission %</strong></th>
				<th style="width:10%;"><strong>Commission Amount $</strong></th>
				<th style="width:10%;"><strong>Agency Commission $</strong></th>
				<th style="width:10%;"><strong>Agent Name</strong></th>
				<th style="width:10%;"><strong>Agent Commission $</strong></th>
				<th style="width:10%;"><strong>Commission paid to Agent Date</strong></th>
				<th style="width:10%;"><strong>Referral Name</strong></th>
				<th style="width:10%;"><strong>Referral Commission %</strong></th>
				<th style="width:10%;"><strong>Referral commission $</strong></th>
				<th style="width:10%;"><strong>Commission paid out to referral date</strong></th>
				<th style="width:10%;"><strong>Commission paid by insurer $</strong></th>
				
				<th style="width:10%;"><strong>Difference in commission</strong></th>
				<th style="width:10%;"><strong>Commission paid date by Insurer</strong></th>
				<th style="width:10%;"><strong>DN</strong></th>
				<th style="width:10%;"><strong>Premium Outstanding</strong></th>
				<th style="width:10%;"><strong>Premium Paid by Client</strong></th>
				<th style="width:10%;"><strong>Premium Paid to Insurer</strong></th>
				<th style="width:10%;"><strong>Premium Paid to Insurer Date</strong></th>
				<th style="width:10%;"><strong>Remarks</strong></th>
				
				<?php 
				if ($sesDataUpdate == "1") {?>
				<th style="width:5%;"><strong>Edit</strong></th>
				<th style="width:5%;"><strong>DN Report</strong></th>
				<?php } if ($dataDelete == "1") { ?>
				<th style="width:5%;"><strong>Delete</strong></th>
				<?php } ?>				
			</tr>
				</thead>
				<tbody>
					<?php
					if(count($result)>0){
						
						foreach($result as $k=>$v) {
							
						if(is_numeric($k)) {
							$date_of_deployment = ($result[$k]["date_of_deployment"]>'2000-01-01') ? $result[$k]["date_of_deployment"] : '';
						
					?>
						<tr>
						<td><?php echo $start+$k+1; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'submission_date','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["submission_date"]; ?></td>
						<td class="client"><?php echo $result[$k]["name_of_client"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'customer_id','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["customer_id"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'policy_number','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["policy_number"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'policy_type','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["policy_type"]; ?></td>
						<?php /*<td contenteditable="true" onBlur="saveToDatabase(this,'policy_duration','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["policy_duration"]; ?></td> */ ?>
						<td><?php echo $result[$k]["abbreviation"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'no_of_workers','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["no_of_workers"]; ?></td>
                            <td class="descr" contenteditable="true" onBlur="saveToDatabase(this,'description','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo nl2br($result[$k]["description"]); ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'premium','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium"]; ?></td>
						<?php /*<td contenteditable="true" onBlur="saveToDatabase(this,'gst','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["gst"]; ?></td>*/?>
						<td contenteditable="true" onBlur="saveToDatabase(this,'premium_wgst','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium_wgst"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'dn_premium','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["dn_premium"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'commission1','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["commission1"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'commission2','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["commission2"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'agency_com','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["agency_com"]; ?></td>
						<td><?php echo $result[$k]["abb"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'agent_com','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["agent_com"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'com_paid_to_agent_date','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["com_paid_to_agent_date"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'referral_name','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["referral_name"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'referral','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["referral"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'referral_com','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["referral_com"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'com_paid_outto_referral_date','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["com_paid_outto_referral_date"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'com_paid_by_insurer','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["com_paid_by_insurer"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'difference_in_com','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["difference_in_com"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'com_paid_date','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["com_paid_date"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'dn','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["dn"]; ?></td>
						
						<td contenteditable="true" onBlur="saveToDatabase(this,'premium_outstanding','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium_outstanding"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'premium_paid_by_client','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium_paid_by_client"]; ?></td>

						<td contenteditable="true" onBlur="saveToDatabase(this,'premium_paid_to_insurer','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium_paid_to_insurer"]; ?></td>
						<td contenteditable="true" onBlur="saveToDatabase(this,'premium_paid_to_insurer_date','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $result[$k]["premium_paid_to_insurer_date"]; ?></td>
						<td class="descr1" contenteditable="true" style="white-space:pre-wrap;" onBlur="saveToDatabase(this,'remarks','<?php echo $result[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo nl2br($result[$k]["remarks"]); ?></td>
						
						
						<?php
						if ($sesDataUpdate == "1") {?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"];?>" class="abc" onclick="window.location.href = 'production_edit.php?id=' + <?php echo $result[$k]["id"];?>">
								<img id="eidtico" name="eidtico" src="img/edit-icon.png" class="utopia-widget-icon" >
								</a>
						</td>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"];?>" class="abc" onclick="window.location.href = 'debit_edit.php?id=' + <?php echo $result[$k]["id"];?>">
								<img id="eidtico" name="eidtico" src="img/export-icon.png" class="utopia-widget-icon" >
						</a>
						</td>
						<?php } if ($dataDelete == "1") { ?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"]; ?>" class="clsdelete" >
									<img id="deleteico" name="deleteico" src="img/delete-icon.png" class="utopia-widget-icon"></a>
						</td>
						<?php } ?> 
						</tr>
						<?php
							}
						}
					}
					?>
				<tbody>

			</table>
			</div>
			<?php
			if(isset($result["perpage"])) { ?>
				<table>
				</br>
				<tr>
					<td colspan="14" align=right> <?php echo $result["perpage"]; ?></td>
				</tr>
				</table>
			<?php } ?>
			</form>	
		</div>
	</body>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
</section>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>