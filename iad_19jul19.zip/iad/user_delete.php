<?php 
error_reporting(0);
include('timeout.php');
require_once("dbcontroller.php");

	$updateid = $_REQUEST["updateid"];

	$sql = "Delete from tbllogin WHERE id = $updateid";
	//echo $sql; die;
	$result = mysql_query($sql);
	if($result == 1){
		echo "Record deleted successfully";
	}else{
		echo "User can not be deleted. Foreign key constrain";
	}
	
	
?>	

