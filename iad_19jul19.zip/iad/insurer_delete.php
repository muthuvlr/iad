<?php
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

if(!empty($_REQUEST["id"])) {
	$result = mysql_query("DELETE FROM insurer_list WHERE id=".$_REQUEST["id"]);
	if(!empty($result)){
		echo "<script language='javascript' type='text/javascript'> window.location='./insurer_view.php'; </script>";
	}
}
?>

