<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("perpage.php");	
require_once("dbcontroller.php");

$db_handle = new DBController();
	
	$agent_name = "";
	$abb = "";
	$updated_by = "";
	$contact_number = "";
	$sesDataUpdate = $_SESSION['SESSION_data_update'];
	$sesExport = $_SESSION['SESSION_export'];
	$dataDelete = $_SESSION['SESSION_data_delete'];
	$queryCondition = "";
	if(isset($_POST['search'])) {
		foreach($_POST["search"] as $k=>$v){
			if(!empty($v)) {

				$queryCases = array("agent_name","abb");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}
				switch($k) {
					case "agent_name":
						$agent_name = $v;
						$queryCondition .= "agent.agent_name LIKE '%" . $v . "%'";
						break;
					case "abb":
						$abb = $v;
						$queryCondition .= "agent.abb LIKE '%" . $v . "%'";
						break;
				}
				$_SESSION['SESSION_agent_EXPORT'] = '';
				$_SESSION['SESSION_agent_page'] = '';
				$_SESSION['SESSION_agent_name'] = $agent_name;
				$_SESSION['SESSION_abb'] = $abb;
			}
		}
	}
	
	$sql = "SELECT agent.id, agent.date_joined, agent.agent_name, agent.abb, agent.updated_by, agent.cell_number, agent.email_id, agent.created_on FROM agent_list as agent 
			LEFT JOIN tbllogin as login on login.id = agent.updated_by" . $queryCondition;
	$orderby = " GROUP BY agent.id ORDER BY id desc"; 
	$href = 'agent_view.php';					

	if(isset($_GET["action"])){
		$_SESSION['SESSION_agent_page'] = '';
		$_SESSION['SESSION_agent_name'] = '';
		$_SESSION['SESSION_abb'] = '';
		$_SESSION['SESSION_agent_EXPORT'] = $sql;
	}else if(!empty($_SESSION['SESSION_agent_EXPORT'])){
		$sql = $_SESSION['SESSION_agent_EXPORT']; 	
	}else{
		$_SESSION['SESSION_agent_EXPORT'] = $sql;
	}

	$perPage = 10; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
		$_SESSION['SESSION_agent_page'] = $page;
	} else {
		if(isset($_SESSION['SESSION_agent_page'])) {
			$page = $_SESSION['SESSION_agent_page'];
		}
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 

	$result = $db_handle->runQuery($query);

	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}
	$agent_name = $_SESSION['SESSION_agent_name'];
	$abb = $_SESSION['SESSION_abb'];

?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet" />

<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
<script type="text/javascript">
$(document).ready(function () 
{
	$('.clsdelete').click(function()
	{
		var essay_id = $(this).attr('id');
		var x;
		if (confirm("Do you want to delete?") == true) 
		{
			$.ajax({
			  type : 'post',
			   url : 'agent_delete.php?', // in here you should put your query 
			   data :{action:'delete',id:essay_id}, // here you pass your id via ajax .
			  
						 // in php you should use $_POST['post_id'] to get this value 
			success : function(r)
			   {
				  // now you can show output in your modal 
				  $('#mymodal').show();  // put your modal id 
				 $('.something').show().html(r);
			   }
			});

		} else 
		{
			//x = "You pressed Cancel!";
			//alert(x + essay_id);
		}
    });
});
</script>
<script type="text/javascript">
	 $(document).ready(function () {
		//alert('hi');
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#date_joined').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        });
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">

	<!-- Individual Page Widget-->
	<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Agent Listing</span>
	</div>
	<body>
		
    <div id="toys-grid">      
			<form name="frmSearch" method="post" action="agent_view.php">
			
			<div class="search-box" style="width:98%; height:40px;">
			<p class="p-tag">
			<input style="width:19%;" type="text" placeholder="Agent Name" name="search[agent_name]" value="<?php echo $agent_name; ?>"	/>
			<input style="width:19%;" type="text" placeholder="Abb" name="search[abb]" value="<?php echo $abb; ?>"	/>

			<input style="width:8%;" type="submit" name="go" class="btnSearch" value="Search..">
			<input style="width:8%;" name="reset" type="reset" class="btnSearch" value="Reset.." onclick="window.location='agent_view.php?action=reset'">
			
			<?php if ($sesDataUpdate == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Addnew" onclick="window.location='agent_edit.php'">
			<?php } 
			if ($sesExport == "1") {?>
			<input style="width:8%;" type="reset" class="btnSearch" value="Export" onclick="window.location='agent_export.php'">
			<?php } ?>
			</p>
			</div>

			<div style="width:100%; height:500px; overflow:auto;">
			<table style="float:left;" class="table table-bordered">
        <thead>
			<tr>
				<th style="width:5%;"><strong>Sl.No</strong></th>
				<th style="width:10%;"><strong>Agent Name</strong></th>
				<th style="width:10%;"><strong>Date Joined</strong></th>
				<th style="width:10%;"><strong>Cell Number</strong></th>
			    <th style="width:10%;"><strong>Abb</strong></th>
				<th style="width:15%;"><strong>Email Id</strong></th>
				<?php 
				if ($sesDataUpdate == "1") {?>
				<th style="width:5%;"><strong>Edit</strong></th>
				<?php } if ($dataDelete == "1") { ?>
				<th style="width:5%;"><strong>Delete</strong></th>
				<?php } ?>				
			</tr>
				</thead>
				<tbody>
					<?php
					if(count($result)>0){
						foreach($result as $k=>$v) {
						if(is_numeric($k)) {
							$date_joined = ($result[$k]["date_joined"]>'2000-01-01') ? $result[$k]["date_joined"] : '';
					?>
						<tr>
						<td><?php echo $start+$k+1; ?></td>
						<td><?php echo $result[$k]["agent_name"]; ?></td> 
						<td><?php echo $date_joined; ?></td> 
						<td><?php echo $result[$k]["cell_number"]; ?></td>
						<td><?php echo $result[$k]["abb"]; ?></td> 
						<td><?php echo $result[$k]["email_id"]; ?></td> 
					
						<?php
						if ($sesDataUpdate == "1") {?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"];?>" class="abc" onclick="window.location.href = 'agent_edit.php?id=' + <?php echo $result[$k]["id"];?>">
								<img id="eidtico" name="eidtico" src="img/edit-icon.png" class="utopia-widget-icon" >
								</a>
						</td>
						<?php } if ($dataDelete == "1") { ?>
						<td>
						<a style="color:black;" href="#" id="<?php echo $result[$k]["id"]; ?>" class="clsdelete" >
									<img id="deleteico" name="deleteico" src="img/delete-icon.png" class="utopia-widget-icon"></a>
						</td>
						<?php } ?> 
						</tr>
						<?php
							}
						}
					}
					if(isset($result["perpage"])) {
					?>
					<tr>
					<td colspan="13" align=right> <?php echo $result["perpage"]; ?></td>
					</tr>
					<?php } ?>
				<tbody>
			</table>
			</div>
			</form>	
		</div>
	</body>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
</section>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>