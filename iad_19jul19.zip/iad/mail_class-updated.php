<?php
error_reporting(-1);
/*require_once('tcpdf_include.php');
require_once(dirname(__FILE__).'/tcpdf.php');
*/
class mailclass
{
    function mailfun($bodycontant,$aid)
    {
  /* 	ob_start();

    	// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('DebitNote');
$pdf->SetTitle('DebitNote');
$pdf->SetSubject('DebitNote');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 001', PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
$pdf->setFooterData(array(0,64,0), array(0,64,128));

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/TCPDF/lang/eng.php')) {
	require_once(dirname(__FILE__).'/TCPDF/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set default font subsetting mode
$pdf->setFontSubsetting(true);

// Set font
// dejavusans is a UTF-8 Unicode font, if you only need to
// print standard ASCII chars, you can use core fonts like
// helvetica or times to reduce file size.
//$pdf->SetFont('dejavusans', '', 10, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->AddPage();

// set text shadow effect
//$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));

// Set some content to print

// Print text using writeHTMLCell()

$pdf->writeHTML($bodycontant, true, 0, true, 0); //ob_clean();

// ---------------------------------------------------------
// Close and output PDF document
// This method has several options, check the source code documentation for more information.
ob_end_clean();
$pdf->lastPage();
//$pdf->Output('example_001.pdf', 'I');
$pdf->Output($_SERVER['DOCUMENT_ROOT'] .'iad/example_001.pdf', 'I');
*/

		$userId = $_SESSION['SESSION_USER_ID'];
		$role_id = $_SESSION['SESSION_role_id'];
		$sessemailId = $_SESSION['SESSION_USER_EMAILID'];
		$sessFirstname = $_SESSION['SESSION_FIRST_NAME'];
	//	$_SESSION['SESSION_HtmlBody'];

		$mailList = [];
		$sql = "SELECT agent_list.email_id FROM production_details inner join agent_list on production_details.agent_id = agent_list.id WHERE production_details.id = '". $aid ."'";
		$res = mysql_query($sql);
		$num_rows = mysql_num_rows($res);
		if($num_rows >0) {
			while($row = mysql_fetch_assoc($res)) {
				if(!empty($row["email_id"])) {
					$mailList[] = $row["email_id"];
				}
			}
		}
		$sql = "SELECT company_list.email_id,company_list.other_email_id FROM production_details inner join company_list on production_details.company_id = company_list.id WHERE production_details.id = '". $aid ."'";
		$res = mysql_query($sql);
		$num_rows = mysql_num_rows($res);
		if($num_rows >0) {
			while($row = mysql_fetch_assoc($res)) {
				if(!empty($row["email_id"])){
					$mailList[] = $row["email_id"];
				}
				if(!empty($row["other_email_id"])) {
					$myArray = explode(',', $row["other_email_id"]);
					foreach($myArray as $my_Array){
					    $mailList[] = $my_Array;  
					}
				}
			}
		}
//		print_r($mailList);
		if(count($mailList)>0) {
			//$emailId = FROM_MAIL;
			$emailId = $sessemailId;
			$from = $sessFirstname . "<" . $emailId .">";
			$to = implode($mailList, ",");
		
			$message = $bodycontant;
			//echo $message;
			$subject = "Debit Note";
			//$headers="";
	        //$semi_rand = md5(time());
	        //$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";

	        //if(strlen($file['name']) < 1){
				//$headers = "MIME-Version: 1.0" . "\r\n";
				//$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				//$headers .= "From:" . $from;
				//echo $message."<br/>Mani";
			//	echo $headers;
//			} else {
				//	$headers .= "From:" . $from;
					// headers for attachment

			//		$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\"\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/html; Content-Type: application/pdf; Content-Type: application/msword; Content-Type: image/jpeg; Content-Type: image/png; Content-Type: application/vnd.ms-excel; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" ;

		            // multipart boundary
		            //$message = $message;
		            //$message .= "--{$mime_boundary}\n";
	//		}*/

			ob_start();
set_time_limit(0);
ini_set("memory_limit", "256M");

require('TCPDF/tcpdf.php');
$tcpdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set default monospaced font
$tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set title of pdf
$tcpdf->SetTitle('Debit Note');

// set margins
$tcpdf->SetMargins(10, 10, 10, 10);
$tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set header and footer in pdf
$tcpdf->setPrintHeader(false);
$tcpdf->setPrintFooter(false);
$tcpdf->setListIndentWidth(3);

// set auto page breaks
$tcpdf->SetAutoPageBreak(TRUE, 11);

// set image scale factor
$tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

if (@file_exists(dirname(__FILE__).'/TCPDF/lang/eng.php')) {
    require_once(dirname(__FILE__).'/TCPDF/lang/eng.php');
    $tcpdf->setLanguageArray($l);
}

$tcpdf->AddPage();
$calibri = TCPDF_FONTS::addTTFfont(K_PATH_FONTS . 'Calibri.ttf', 'TrueTypeUnicode', '', 32);
$cambria = TCPDF_FONTS::addTTFfont(K_PATH_FONTS . 'Cambria.ttf', 'TrueTypeUnicode', 'I', 32);
 
 
// use the font

$tcpdf->SetFont($calibri, 'I', 10);
$tcpdf->SetFont($cambria, 'I', 10);
//$tcpdf->SetStyle( "style", $cambria, "BI", 10);
//$tcpdf->SetFont('times', '', 10.5);
$tcpdf->setPageMark();
$tcpdf->writeHTML($message, true, false, true, false, '');

	$file = $_SERVER['DOCUMENT_ROOT'] .'iad/demo.pdf';
$filename="debit_note.pdf";	

$attachment = $tcpdf->Output($file, 'E');
//$attachment = $tcpdf->Output($filename, 'E');
/* 	
$file_size = filesize($file);
$handle = fopen($file, "r");
$content = fread($handle, $file_size);
fclose($handle);

$content = chunk_split(base64_encode($content)); */
ob_end_clean(); 
//$name = basename($file);
$uid = md5(uniqid(time()));
	$eol = PHP_EOL;
 $header = "From: ".$from.$eol;
 $header .= "Reply-To: ".$to.$eol;
 //$header .= "MIME-Version: 1.0".$eol;
 $header .= "MIME-Version: 1.0\r\n";
 $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"";
 //$header .= "This is a multi-part message in MIME format.\r\n";
 $message  = "--".$uid.$eol;
 $message  = "Content-type:text/html; charset=iso-8859-1".$eol;
 $message  .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
 $message  .= $bodycontant.$eol;
 $message  .= "--".$uid.$eol;
 $message  .= "Content-Type: application/pdf; name=\"".$filename."\"".$eol; // use different content types here
 $message  .= "Content-Transfer-Encoding: base64".$eol;
 $message  .= "Content-Disposition: attachment; filename=\"".$filename."\"".$eol;
 $message  .= $attachment.$eol;
 $message  .= "--".$uid."--"; 
	        $success = @mail($to, $subject, $message, $header);
	        if($success) {
	        	$msg = "Mail sent Success!";
				echo '<h3 align="center" style="color:green">'. $msg.'</h3>'; 
			}else{
				$errorMessage = error_get_last()['message'];
				$msg = "Problem in sending Mail..!";
				echo '<h3 align="center" style="color:red">'. $msg.$errorMessage.'</h3>'; 
			}
		}
	
	}
}

?>	
