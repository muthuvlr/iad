<?php 
error_reporting(0);
include('auth.php'); //user_profile Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

	if(isset($_POST['submit']))
	{
		$updateid = $_REQUEST["updateid"];
		$role_name = $_REQUEST["role_name"];
		
		if (!empty($_POST['export'])){$export=1;}
		else{$export = 0;}

		if (!empty($_POST['data_delete'])){$data_delete=1;}
		else{$data_delete = 0;}

		if (!empty($_POST['user_profile'])){$user_profile=1;}
		else{$user_profile = 0;}

		if (!empty($_POST['roles_update'])){$roles_update=1;}
		else{$roles_update = 0;}

		if (!empty($_POST['roles_view'])){$roles_view=1;}
		else{$roles_view = 0;}
		
		if (!empty($_POST['data_update'])){$data_update=1;}
		else{$data_update = 0;}

		if (!empty($_POST['companylist'])){$companylist=1;}
		else{$companylist = 0;}

		if (!empty($_POST['agentlist'])){$agentlist=1;}
		else{$agentlist = 0;}
		
		if (!empty($_POST['insurerlist'])){$insurerlist=1;}
		else{$insurerlist = 0;}

		if (!empty($_POST['productionlist'])){$productionlist=1;}
		else{$productionlist = 0;}

		$sql = "UPDATE tblroles SET role_name='$role_name',productionlist='$productionlist',companylist='$companylist',agentlist='$agentlist',insurerlist='$insurerlist',Export='$export',user_profile='$user_profile',roles_view='$roles_view',roles_update='$roles_update',data_update='$data_update',data_delete='$data_delete' WHERE id = $updateid";

		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		
		$user_level = $_SESSION['SESSION_USER_ROLE'];

		$sql="SELECT * FROM tblroles WHERE role_name='".$user_level."'";
	
			$result = mysql_query($sql);
			$numrows = mysql_num_rows($result);

			if ($numrows > 0)
			{	
				$row = mysql_fetch_array($result);
				$_SESSION['SESSION_role_name'] = $row['role_name'];
				$_SESSION['SESSION_export'] =$row['export'];
				$_SESSION['SESSION_data_delete'] =$row['data_delete'];
				$_SESSION['SESSION_user_profile'] =$row['user_profile'];
				$_SESSION['SESSION_roles_update'] =$row['roles_update'];
				$_SESSION['SESSION_roles_view'] =$row['roles_view'];
				$_SESSION['SESSION_data_update'] =$row['data_update'];
				$_SESSION['SESSION_productionlist'] =$row['productionlist'];
				$_SESSION['SESSION_companylist'] =$row['companylist'];
				$_SESSION['SESSION_agentlist'] =$row['agentlist'];
				$_SESSION['SESSION_insurerlist'] =$row['insurerlist'];
			}

		echo "<script>var a = 'Record Updated Successfully';alert(a);</script>
		<script language='javascript' type='text/javascript'>window.location='./roles_view.php';</script>";
	}
?>	
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function () {
$("#clear").click(function(){
	$('#role_name').val("");
    });
    });
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('input[name="role_name"]').blur(function(){
        var txt = $(this);
        var updateid = $('#updateid').val();
        var role_name = txt.val();
        $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { role_name: role_name,updateid:updateid}
        }).done(function(res) {
            if (res == 1){
            	alert('Rolename already exist!');
                $('#role_name').val("");
            } else {
                return false;
            }
        });
    });
});
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%">
	<form method="post" action="" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Update Roles & Permisson</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:400px;width:100%">
		<?php
		if(isset($_GET["id"]))
		 {
			$gid= $_GET["id"];
			$sql = "SELECT * FROM tblroles WHERE id = $gid";
			$result = mysql_query($sql);
			$row = mysql_fetch_array($result);
			$id = $row['id'];
			$role_name = $row['role_name'];
			$export = $row['export'];
			$user_profile = $row['user_profile'];
			$roles_view = $row['roles_view'];
			$roles_update = $row['roles_update'];
			$data_delete = $row['data_delete'];
			$data_update = $row['data_update'];
			$productionlist = $row['productionlist'];
			$companylist = $row['companylist'];
			$agentlist = $row['agentlist'];
			$insurerlist = $row['insurerlist'];
			
		?>
		<input type="hidden" readonly id="updateid" name="updateid" value="<?php echo $id;?>"/>
		<table>
		<tr>
				<td>
				<label style="width:100px;">Role Name *: </label>
				</td>
				<td>
				<input required style="width:200px;" type="text" id="role_name" name="role_name" value="<?php echo $role_name;?>"/>
				</td>
			<tr><td>&nbsp;&nbsp;&nbsp;</td><td></td></tr>
		</table>	
		</br>
		<table style="width:100%">
			</tr>
				<tr>
				<td ><label style="width:100px;">Permission : </label></td>
				<td style="width:250px;">
					<input name="productionlist" type="checkbox" value="productionlist" <?php if($productionlist=="1") echo "checked=checked"; ?> > Production List
				</td>
				<td style="width:250px;">
					<input name="companylist" type="checkbox" value="companylist" <?php if($companylist=="1") echo "checked=checked"; ?> > Company List
				</td>
				<td style="width:250px;">
					<input name="agentlist" type="checkbox" value="agentlist" <?php if($agentlist=="1") echo "checked=checked"; ?> > Agent List
				</td>
				<td style="width:250px;">
					<input name="insurerlist" type="checkbox" value="insurerlist" <?php if($insurerlist=="1") echo "checked=checked"; ?> > Insurer List
				</td>
				
				<td style="width:250px;">
				
				</td>
				</tr>
				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td style="width:250px;">
					<input name="export" type="checkbox" value="export" <?php if($export=="1") echo "checked=checked"; ?> > Export 
				</td>
				<td>
				<input name="user_profile" type="checkbox" value="user_profile" <?php if($user_profile=="1") echo "checked=checked"; ?> > User Profile
				</td>
				<td>
				<input name="roles_view" type="checkbox" value="roles_view" <?php if($roles_view=="1") echo "checked=checked"; ?> > Roles View
				</td>
				<td>
				<input name="roles_update" type="checkbox" value="roles_update" <?php if($roles_update=="1") echo "checked=checked"; ?> > Roles Update
				</td>
				
				<td style="width:250px;">
				
				</td>
				</tr>

				<tr><td>&nbsp;&nbsp;&nbsp;</td></tr>
				<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td>
				<input name="data_delete" type="checkbox" value="data_delete" <?php if($data_delete=="1") echo "checked=checked"; ?> > Delete
				</td>
				<td>
				<input name="data_update" type="checkbox" value="data_update" <?php if($data_update=="1") echo "checked=checked"; ?> > Data Update
				</td>
				<td>
				</td>
				<td>
				</td>
				<td>
				</td>
				<td style="width:250px;">
				
				</td>
				</tr>
				</table>

			</br>
			</br>
			<table>
			<tr>
				<td style="width:100px;">&nbsp;&nbsp;&nbsp;</td>
				<td><input style="width:100px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit"></td>
				<td>&nbsp;&nbsp;&nbsp;</td>
				<td><input style="width:100px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='roles_view.php';"></td>
			</tr>
			</table>	

		<?php 
		}
		?>
	</div>
	</div>
	</div>
	</section>
	
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>