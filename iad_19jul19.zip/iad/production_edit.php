<?php 
error_reporting(0);
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
include('common_class.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

$imgclear = 0;
$name_of_client = $_POST["name_of_client"];
$customer_id = $_POST["customer_id"];
$policy_number = $_POST["policy_number"];
$policy_type = $_POST["policy_type"];
$policy_duration = $_POST["policy_duration"];
$insurer = $_POST["insurer"];
$no_of_workers = $_POST["no_of_workers"];
$description = $_POST["description"];
$description = str_replace("'","\'",$description);
$premium = empty($_POST["premium"]) ? 0 :$_POST["premium"];
$premium_wgst = empty($_POST["premium_wgst"]) ? 0 :$_POST["premium_wgst"];
$dn_premium = empty($_POST["dn_premium"]) ? 0 :$_POST["dn_premium"];
$gst = empty($_POST["gst"]) ? 0 :$_POST["gst"];
$commission1 = $_POST["commission1"];
$commission1 = empty($commission1) ? '15' : $commission1 ;
$commission2 = empty($_POST["commission2"]) ? 0 :$_POST["commission2"];
$agency_com = empty($_POST["agency_com"]) ? 0 :$_POST["agency_com"];
$agent_name = $_POST["agent_name"];
$agent_com = empty($_POST["agent_com"]) ? 0 :$_POST["agent_com"];
//$com_paid_to_agent_date = empty($_POST["com_paid_to_agent_date"]) ? 0 :$_POST["com_paid_to_agent_date"];
$referral_name = $_POST["referral_name"];
$referral = $_POST["referral"];
$referral = empty($referral) ? '0' : $referral ;
$referral_com = empty($_POST["referral_com"]) ? 0 : $_POST["referral_com"];
$com_paid_by_insurer = empty($_POST["com_paid_by_insurer"]) ? 0 : $_POST["com_paid_by_insurer"];

$com_paid_outto_referral_date = $_POST["com_paid_outto_referral_date"];
$com_paid_date = $_POST["com_paid_date"];
$submission_date = $_POST["submission_date"];
$com_paid_to_agent_date = $_POST["com_paid_to_agent_date"];
$remarks = $_POST["remarks"];
$remarks = str_replace("'","\'",$remarks);
$difference_in_com = empty($_POST["difference_in_com"]) ? 0 :$_POST["difference_in_com"];
$premium_outstanding = empty($_POST["premium_outstanding"]) ? 0 :$_POST["premium_outstanding"];
$dn = empty($_POST["dn"]) ? 0 :$_POST["dn"];
$premium_paid_to_insurer = empty($_POST["premium_paid_to_insurer"]) ? 0 :$_POST["premium_paid_to_insurer"];
$premium_paid_by_client = empty($_POST["premium_paid_by_client"]) ? 0 :$_POST["premium_paid_by_client"];
$premium_paid_to_insurer_date = $_POST["premium_paid_to_insurer_date"];
date_default_timezone_set("Asia/Kolkata");
//$com_paid_date = date('Y-m-d H:i:s');
$active_status = 1;
//date('Y-m-d',strtotime($_REQUEST['com_paid_by_insurer']));


$now = date('Y-m-d');
$userId = $_SESSION['SESSION_USER_ID'];
$bFlag = true;
$errMsg = "";

if(!empty($_POST["submit"])) {
	$clsCommon = new commonclass();
	$company_id = $clsCommon->getId($name_of_client,'client');
	$agent_id = $clsCommon->getId($agent_name,'agent');
	$insurer_id = $clsCommon->getId($insurer,'insurer');
	if($company_id == 0) {
		$errMsg =  "Company name not found in the company list";
		$bFlag = false;
	}
	else if($insurer_id == 0) {
		$errMsg =  "Insurer name not found in the Insurer list";
		$bFlag = false;
	}
	else if($agent_id == 0) {
		$errMsg =  "Agent name not found in the agent list";
		$bFlag = false;
	}
	
	
}

if(!empty($_GET["id"]) && $bFlag == true) {
	if(!empty($_POST["submit"])) {
		
		$com_paid_outto_referral_date = empty($com_paid_outto_referral_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_outto_referral_date ."'";
		$com_paid_date = empty($com_paid_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_date ."'";
		$com_paid_to_agent_date = empty($com_paid_to_agent_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_to_agent_date ."'";
		$premium_paid_to_insurer_date = empty($premium_paid_to_insurer_date) ? mysql_real_escape_string('NULL') : "'" . $premium_paid_to_insurer_date ."'";
		

		$gId = $_GET["id"];
		$sqlQuery = "UPDATE production_details set 
			company_id = '".$company_id."', 
			policy_number = '".$policy_number."', 
			policy_type = '".$policy_type."', 
			policy_duration = '".$policy_duration."', 
			insurer = '".$insurer_id."', 
			no_of_workers = '".$no_of_workers."', 
			description = '".$description."', 
			premium = '".$premium."', 
			premium_wgst = '".$premium_wgst."', 
			dn_premium = '".$dn_premium."', 
			gst = '".$gst."', 
			commission1 = '".$commission1."', 
			commission2 = '".$commission2."',
			agency_com = '".$agency_com."',
			agent_id = '".$agent_id."', 
			agent_com = '".$agent_com."', 
			com_paid_to_agent_date = ".$com_paid_to_agent_date.", 
			referral_name = '".$referral_name."', 
			referral = '".$referral."', 
			referral_com = '".$referral_com."', 
			com_paid_by_insurer = '".$com_paid_by_insurer."', 
			com_paid_outto_referral_date = ".$com_paid_outto_referral_date.", 
			com_paid_date = ".$com_paid_date.", 
			difference_in_com = '".$difference_in_com."', 
			premium_outstanding = '".$premium_outstanding."', 
			dn = '".$dn."', 
			premium_paid_to_insurer = '".$premium_paid_to_insurer."', 
			premium_paid_by_client = '".$premium_paid_by_client."', 
			premium_paid_to_insurer_date = ".$premium_paid_to_insurer_date.", 
			submission_date = '".$submission_date."', 
			remarks = '".$remarks."', 
			active_status = ".$active_status.", 
			updated_on = '".$now."', 
			updated_by = '".$userId."'";

		$condtion = " WHERE  id=".$gId;
		$sqlQuery = $sqlQuery . $condtion; 

		$result = mysql_query($sqlQuery);
		if(!$result){
			$message = "Problem in Editing! Please Retry!";
		} else {
			$sqlQuery = "INSERT INTO production_logs(production_id,company_id, policy_number, policy_type, policy_duration, insurer, no_of_workers, description, premium, gst, premium_wgst,dn_premium, commission1, commission2,agency_com, agent_id, agent_com,com_paid_to_agent_date, referral_name,referral, referral_com, com_paid_by_insurer, com_paid_outto_referral_date, com_paid_date, difference_in_com, premium_outstanding, dn, premium_paid_to_insurer, premium_paid_by_client, premium_paid_to_insurer_date,submission_date, remarks,  active_status, created_on, created_by, updated_on, updated_by) 
			VALUES($gId,'".$company_id."','".$policy_number."','".$policy_type."','".$policy_duration."','".$insurer_id."','".$no_of_workers."','".$description."','".$premium."','".$gst."','".$premium_wgst."','".$dn_premium."','".$commission1."','".$commission2."','".$agency_com."','".$agent_id."','".$agent_com."','".$com_paid_to_agent_date."','".$referral_name."','".$referral."','".$referral_com."','".$com_paid_by_insurer."',".$com_paid_outto_referral_date.",".$com_paid_date.",'".$difference_in_com."','".$premium_outstanding."','".$dn."','".$premium_paid_to_insurer."','".$premium_paid_by_client."',".$premium_paid_to_insurer_date.",'".$submission_date."','".$remarks."',".$active_status.",'". $now."','".$userId."','".$now."','".$userId."')";

			$result1 = mysql_query($sqlQuery);
			echo "<script language='javascript' type='text/javascript'>window.location='./production_inline.php';</script>";
			//header("Location:production_view.php");
		}
	}
	$result = $db_handle->runQuery("SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type,pde.policy_duration, ilist.abbreviation as insurer , pde.no_of_workers, pde.description, pde.premium, pde.gst, pde.premium_wgst, pde.dn_premium, pde.commission1, pde.commission2, pde.agency_com, alist.abb as agent_name, pde.agent_com,pde.com_paid_to_agent_date, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.premium_paid_to_insurer, pde.premium_paid_by_client,pde.premium_paid_to_insurer_date, pde.submission_date, pde.remarks FROM production_details as pde
			INNER JOIN company_list as clist on clist.id = pde.company_id  
			INNER JOIN agent_list as alist on alist.id = pde.agent_id
			LEFT JOIN insurer_list as ilist on ilist.id = pde.insurer			
			LEFT JOIN tbllogin as login on login.id = pde.updated_by WHERE pde.id='" . $_GET["id"] . "'");
			
}
else{
	if(!empty($_POST["submit"])  && $bFlag == true) {
		
		$com_paid_outto_referral_date = empty($com_paid_outto_referral_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_outto_referral_date ."'";
		$com_paid_date = empty($com_paid_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_date ."'";
		$com_paid_to_agent_date = empty($com_paid_to_agent_date) ? mysql_real_escape_string('NULL') : "'" . $com_paid_to_agent_date ."'";
		$premium_paid_to_insurer_date = empty($premium_paid_to_insurer_date) ? mysql_real_escape_string('NULL') : "'" . $premium_paid_to_insurer_date ."'";
		
		$sqlQuery = "INSERT INTO production_details(company_id, policy_number, policy_type, policy_duration, insurer, no_of_workers, description, premium, gst, premium_wgst, dn_premium, commission1, commission2,agency_com, agent_id, agent_com,com_paid_to_agent_date, referral_name,referral, referral_com, com_paid_by_insurer, com_paid_outto_referral_date, com_paid_date, difference_in_com, premium_outstanding, dn, premium_paid_to_insurer, premium_paid_by_client, premium_paid_to_insurer_date, submission_date, remarks, active_status, created_on, created_by, updated_on, updated_by) 
		VALUES('".$company_id."','".$policy_number."','".$policy_type."','".$policy_duration."','".$insurer_id."','".$no_of_workers."','".$description."','".$premium."','".$gst."','".$premium_wgst."','".$dn_premium."','".$commission1."','".$commission2."','".$agency_com."','".$agent_id."','".$agent_com."' ,".$com_paid_to_agent_date." ,'".$referral_name."','".$referral."','".$referral_com."','".$com_paid_by_insurer."',".$com_paid_outto_referral_date.",".$com_paid_date.",'".$difference_in_com."','".$premium_outstanding."','".$dn."','".$premium_paid_to_insurer."','".$premium_paid_by_client."',".$premium_paid_to_insurer_date.",'".$submission_date."','".$remarks."',".$active_status.",'". $now."','".$userId."','".$now."','".$userId."')";

		$result = mysql_query($sqlQuery);
		if(!$result){
				$message="Problem in Adding to database. Please Retry.";
		} else {
			echo "<script language='javascript' type='text/javascript'>window.location='./production_inline.php';</script>";
		}
	}
	$result = $db_handle->runQuery("SELECT dn FROM production_details ORDER by dn desc limit 1");
	if(empty($result)) {
		$dn='8000';
	}
	else if($result[0]['dn']>='8000'){
		$dn = $result[0]['dn']+1;
	}
	else{
		$dn='8000';
	}
	
	//$result[0]['dn'];
}
if(!empty($_GET["lid"])) {
	$result = $db_handle->runQuery("SELECT * FROM production_details WHERE id='" . $_GET["lid"] . "'");
}

?>	
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script language="JavaScript" type="text/javascript" src="js/autoComplete.js"></script>
<script type="text/javascript">
$(document).ready(function () {
	$("#clear").click(function(){
		$('#name_of_client').val("");
		$('#customer_id').val("");
		$('#policy_number').val("");
		$('#policy_type').val("");
		$('#policy_duration').val("");
		$('#insurer').val("");
		$('#no_of_workers').val("");
		$('#description').val("");
		$('#premium').val("");
		$('#premium_wgst').val("");
		$('#dn_premium').val("");
		$('#gst').val("");
		$('#commission1').val("");
		$('#commission2').val("");
		$('#agency_com').val("");
		$('#agent_name').val("");
		$('#agent_com').val("");
		$('#com_paid_to_agent_date').val("");
		$('#referral_name').val("");
		$('#referral').val("");
		$('#referral_com').val("");
		$('#com_paid_by_insurer').val("");
		$('#com_paid_outto_referral_date').val("");
		$('#com_paid_date').val("");
		$('#difference_in_com').val("");
		$('#premium_outstanding').val("");
		$('#submission_date').val("");
		$('#remarks').val("");
		$('#dn').val("");
		$('#premium_paid_to_insurer').val("");
		$('#premium_paid_by_client').val("");
		$('#premium_paid_to_insurer_date').val("");
	    });
    });
</script>
<script type="text/javascript">
	 $(document).ready(function () {
		//alert('hi');
		var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        var yyyy = today.getFullYear();
        if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} var today = dd+'-'+mm+'-'+yyyy;
        $('#com_paid_outto_referral_date').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#com_paid_date').datepicker({
            dateFormat: 'yy-mm-dd',
            weekStart: '0'
        });
        $('#submission_date,#com_paid_to_agent_date,#premium_paid_to_insurer_date').datepicker({
            dateFormat: 'yy-mm-dd',
            setDate: new Date(),
            weekStart: '0'
        });
        document.prodform.name_of_client.focus();

        function fncalculate(pr) {
        	var premium = document.prodform.premium.value;
        	//var gst = document.prodform.gst.value;
			if(pr){
				//alert(pr);
			$('#premium_wgst').val(premium * 1.07);
			//$('#premium_wgst').val(premium * gst);
			//$('#dn_premium').val(premium * 1.07);
			}

			var commission1 = document.prodform.commission1.value;
			var commission2 = document.prodform.commission2.value;
			$('#commission2').val(premium * (commission1/100));

			var kcommission2 = document.prodform.commission2.value;
			$('#agency_com').val(kcommission2 * 0.3);

			var referral = document.prodform.referral.value;
			$('#referral_com').val(commission2 * (referral/100));

			var icommission2 = document.prodform.commission2.value;
			var iagency_com = document.prodform.agency_com.value;
			var referral_com = document.prodform.referral_com.value;
			$('#agent_com').val(icommission2 - iagency_com - referral_com);

			var rt_referral = document.prodform.referral.value;
			var rt_commission2 = document.prodform.commission2.value;
			$('#referral_com').val(rt_commission2 * (rt_referral/100));

			var commission2 = document.prodform.commission2.value;
			var com_paid_by_insurer = document.prodform.com_paid_by_insurer.value;
			$('#difference_in_com').val(icommission2 - com_paid_by_insurer);

			//var rt_premium_wgst = document.prodform.premium_wgst.value;
			var rt_premium_wgst = document.prodform.dn_premium.value;
			var premium_paid_by_client = document.prodform.premium_paid_by_client.value;
			$('#premium_outstanding').val(rt_premium_wgst - premium_paid_by_client);
        }

        $('input[name="premium"]').blur(function(){
        	fncalculate(1); 
		})
		$('input[name="gst"]').blur(function(){
        	fncalculate(); 
		})
		$('input[name="commission1"]').blur(function(){
        	fncalculate(); 
		})
		$('input[name="referral"]').blur(function(){
        	fncalculate(); 
		})
		$('input[name="com_paid_by_insurer"]').blur(function(){
        	fncalculate(); 
		})
		$('input[name="premium_paid_by_client"]').blur(function(){
        	fncalculate(); 
		})

    });
</script>
<script language="javascript">
function InsertBreak(e){
		//check for return key=13
		if (parseInt(e.keyCode)==13) {
			//get textarea object
			var objTxtArea;
			objTxtArea=document.getElementById("test");
	//insert the existing text with the <br>
		objTxtArea.innerText=objTxtArea.value+"\n";
		}
	}
function Validate1()
{
	var name_of_client = $('#ClientName').val();
    $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { name_of_client: name_of_client,updateid:updateid}
        }).done(function(res) {
        	console.log(res);
            if (res == 0){
            	alert('Name of client not found in companylist master!');
                $('#name_of_client').val("");
                return false;
            }
        });
    var agent_name = $('#AgentName').val();
    $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { agent_name: agent_name,updateid:updateid}
        }).done(function(res) {
            if (res == 0){
            	alert('Agent name not found in agentlist master!');
                $('#agent_name').val("");
                return false;
            }
        });     
}
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('input[name="name_of_client1"]').blur(function(){
        var txt = $(this);
        var updateid = $('#updateid').val();
        var name_of_client = txt.val();
        $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { name_of_client: name_of_client,updateid:updateid}
        }).done(function(res) {
        	console.log(res);
            if (res == 0){
            	alert('Name of client not found in companylist master!');
                $('#name_of_client').val("");
                return false;
            }
        });
    });
    $('input[name="agent_name1"]').blur(function(){
        var txt = $(this);
        var updateid = $('#updateid').val();
        var agent_name = txt.val();
        $.ajax({
            type: "POST",
            url: "column_validation.php",
            data: { agent_name: agent_name,updateid:updateid}
        }).done(function(res) {
        	console.log(res);
            if (res == 0){
            	alert('Agent name not found in agentlist master!');
                $('#agent_name').val("");
                return false;
            }
        });
    });
});
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9" style="width:100%">
<form id="autoCompleteSearch" action="" name="prodform" method='post' enctype="multipart/form-data" class="form-horizontal">
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Add/Update Production Details</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace" style="height:650px;">
		<?php
		if(isset($_GET["id"]))
		{
			
			$id = $result[0]["id"];
			$name_of_client = $result[0]["name_of_client"];
			$customer_id = $result[0]["customer_id"];
			$policy_number = $result[0]["policy_number"];
			$policy_type = $result[0]["policy_type"];
			$policy_duration = $result[0]["policy_duration"];
			$insurer = $result[0]["insurer"];
			$no_of_workers = $result[0]["no_of_workers"];
			$description = $result[0]["description"];
			$premium = $result[0]["premium"];
			$gst = $result[0]["gst"];
			$premium_wgst = $result[0]["premium_wgst"];
			$dn_premium = $result[0]["dn_premium"];
			$commission1 = $result[0]["commission1"];
			$commission2 = $result[0]["commission2"];
			$agent_name = $result[0]["agent_name"];
			$agent_com = $result[0]["agent_com"];
			$com_paid_to_agent_date = $result[0]["com_paid_to_agent_date"];
			$referral_name = $result[0]["referral_name"];
			$referral = $result[0]["referral"];
			$referral_com = $result[0]["referral_com"];
			$com_paid_by_insurer = $result[0]["com_paid_by_insurer"];
			$com_paid_outto_referral_date = $result[0]["com_paid_outto_referral_date"];
			$com_paid_date = $result[0]["com_paid_date"];
			$difference_in_com = $result[0]["difference_in_com"];
			$premium_outstanding = $result[0]["premium_outstanding"]; 
			$dn = $result[0]["dn"];
			$premium_paid_to_insurer = $result[0]["premium_paid_to_insurer"];
			$premium_paid_by_client = $result[0]["premium_paid_by_client"];
			$premium_paid_to_insurer_date = $result[0]["premium_paid_to_insurer_date"];
			$submission_date = $result[0]["submission_date"];
			$remarks = $result[0]["remarks"];
			$updated_by = $result[0]["updated_by"];
			$active_status = $result[0]["active_status"];
		}
		
		?>
			<table>
				<tr><td colspan="5" style="text-align:center">
				<?php 
					echo '<h3 style="color:red">'. $errMsg.'</h3>'; 
				?>
				</td></tr>
			<tr>
				<td>
				<label style="width:160px;">Name of client *: </label>
				</td>
				<td>
				<input required style="width:250px;" type="text" id="ClientName" name="name_of_client" alt="Search Criteria" onkeyup="searchAutoComplete();" autocomplete="off" value="<?php echo $name_of_client;?>"/>
				<div id="layer1"></div>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
					<label style="width:160px;">Policy duration : </label>
				</td>
				<td><input type="hidden" readonly id="updateid" name="updateid" value="<?php echo $id;?>"/>
					<input style="width:250px;" type="text" id="policy_duration" name="policy_duration" value="<?php echo $policy_duration;?>"/>
				</td>
			</tr>
			
			<tr>
				<td>
				<label style="width:160px;">Policy number : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="policy_number" name="policy_number" value="<?php echo $policy_number;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label style="width:150px;">Policy type *: </label>
				</td>
				<td>
				<input required style="width:250px;" type="text" id="policy_type" name="policy_type" value="<?php echo $policy_type;?>"/>
				</td>
			</tr>

			<tr>
				<td>
				<label style="width:130px;">Insurer *: </label>
				</td>
				<td>
				<input style="width:250px;" required type="text" id="insurer" name="insurer" value="<?php echo $insurer;?>" alt="Search Criteria" onkeyup="searchAutoCompleteInsurer();" autocomplete="off" />
				<div id="layerInsurer"></div>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label>No of workers : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="no_of_workers" name="no_of_workers" value="<?php echo $no_of_workers;?>"/>
				</td>
			</tr>

			<tr>
			<td>
                <label>Description : </label>
                </td>
                <td colspan="4">
                <textarea rows="2" cols="250" name="description" onkeydown="InsertBreak(event);" class="textfield" id="description" style="width:99%"/><?php echo $description;?></textarea>
                </td>
                <td>
                </td>
			</tr>
			<tr>
				<td>
				<label>Premium ($) : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="premium" name="premium" value="<?php echo $premium;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label>Premium wgst ($) : </label>
				</td>
				<td>
				<input style="width:50px; display:none;" type="text" id="gst" name="gst" readonly value="<?php echo "7";//echo $gst; %?>"/>
				<input style=" width:250px;" type="text" id="premium_wgst" name="premium_wgst" value="<?php echo $premium_wgst;?>"/>
				</td>
				</tr>
			<tr>
				<td>
				<label>DN Premium ($) : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="dn_premium" name="dn_premium" value="<?php echo $dn_premium;?>"/>
				</td>
			<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				
				<td>
				<label>Commission (%) : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="commission1" name="commission1" value="<?php echo $commission1;?>"/>
				</td>
				
				</tr>
			<tr>
				<td>
				<label>Commission Amount ($) : </label>
				</td>
				<td>
				<input readonly style="width:250px;" type="text" id="commission2" name="commission2" value="<?php echo $commission2;?>"/>
				</td>
			<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
				<label>Agency Com ($) : </label>
				</td>
				<td>
				<input readonly style="width:250px;" type="text" id="agency_com" name="agency_com" value="<?php echo $agency_com;?>"/>
				</td>
				</tr>
			<tr>
				<td>
					<label>Agent Name *: </label>
				</td>
				<td>
					<input required style="width:250px;" type="text" id="AgentName" name="agent_name" alt="Search Criteria" onkeyup="searchAutoComplete2();" autocomplete="off" value="<?php echo $agent_name;?>"/>
					<div id="layer2"></div>
				</td>
			<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td>
					<label>Agent Com ($) : </label>
				</td>
				<td>
					<input readonly style="width:250px;" type="text" id="agent_com" name="agent_com" value="<?php echo $agent_com;?>"/>
				</td>
				</tr>
			<tr>
				<td>
					<label>Com paid to Agent Date : </label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="com_paid_to_agent_date" name="com_paid_to_agent_date" value="<?php echo $com_paid_to_agent_date;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				
				<td>
					<label>Referral Name : </label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="referral_name" name="referral_name" value="<?php echo $referral_name;?>"/>
				</td>
				</tr>
			<tr>
				<td>
					<label>Referral Commission (%) : </label>
				</td>
				<td>
				<input style="width:250px;" type="text" id="referral" name="referral" value="<?php echo $referral;?>"/>
				</td>
								<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>

				
				<td>
					<label>Referral Commission ($) : </label>
				</td>
				<td>
					<input readonly style="width:250px;" type="text" id="referral_com" name="referral_com" value="<?php echo $referral_com;?>"/>
				</td>
				</tr><tr>
				<td>
					<label>Com paid out to ref date : </label>
				</td>
								

				<td>
					<input style="width:250px;" type="text" id="com_paid_outto_referral_date" name="com_paid_outto_referral_date" value="<?php echo $com_paid_outto_referral_date;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
<td>
					<label>Com paid by insurer ($) : </label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="com_paid_by_insurer" name="com_paid_by_insurer" value="<?php echo $com_paid_by_insurer;?>"/>
				</td>

</tr><tr>				
		
				
				

				<td>
					<label>Difference in com : </label>
				</td>
				<td>
					<input readonly style="width:250px;" type="text" id="difference_in_com" name="difference_in_com" value="<?php echo $difference_in_com;?>"/>
				</td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
								<td>
					<label>Com paid date by Insurer: </label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="com_paid_date" name="com_paid_date" value="<?php echo $com_paid_date;?>"/>
				</td>
								</tr><tr>

				<td>
					<label>DN : </label>
				</td>
				<td>
					<input style="width:250px;" readonly type="text" id="dn" name="dn" value="<?php echo $dn;?>"/>
				</td>
							<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
<td>
					<label>Premium outstanding : </label>
				</td>

				<td>
					<input readonly style="width:250px;" type="text" id="premium_outstanding" name="premium_outstanding" value="<?php echo $premium_outstanding;?>"/>
				</td>
								</tr><tr>

				<td>
					<label>Premium paid by client : </label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="premium_paid_by_client" name="premium_paid_by_client" value="<?php echo $premium_paid_by_client;?>"/>
				</td>
				
							<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
							<td>
					<label>Premium Paid To Insurer : </label>
				</td>
				<td>
				
					<input style="width:250px;" type="text" id="premium_paid_to_insurer" name="premium_paid_to_insurer" value="<?php echo $premium_paid_to_insurer;?>"/></td>

</tr><tr>
<td>
				<label>Premium paid to insurer Date :</label>
				</td>
				<td>
					<input style="width:250px;" type="text" id="premium_paid_to_insurer_date" name="premium_paid_to_insurer_date" value="<?php echo $premium_paid_to_insurer_date;?>"/>
					
				</td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>

				<td>
				<label>Submission Date *:</label>
				</td>
				<td>
					<input style="width:250px;" required type="text" id="submission_date" name="submission_date" value="<?php echo $submission_date;?>"/>
				</td>				
		
				
				</tr><tr>
				<td>
                <label>Remarks : </label>
                </td>
                <td colspan="4">
                <textarea rows="2" cols="250" onkeydown="InsertBreak(event);" name="remarks" class="textfield" id="remarks" style="width:99%"/><?php echo $remarks;?></textarea>
                </td>
                <td>
                </td>
			</tr>

			<tr><td colspan="4">&nbsp&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td></tr><tr>
				<td></td>
				<td colspan="3">
				<table>
				<tr>
				<td><input style="width:120px;" class="btn btn-success span5" type="submit" id="submit" name="submit" value="Submit" onclick="return Validate()"></td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td><input style="width:120px;" class="btn btn-primary span4" id="clear" name="clear" type="button" value="Clear"></td>
				<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
				<td><input style="width:120px;" class="btn btn-danger span4" type="button" value="Cancel" onClick="window.location='production_inline.php';"></td>
				</tr>
				</table>
				</td>
			</tr>
		</table>

	</div>
	</div>
	</div>
	</section>
	
	</form>
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>