<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
    $breaks = array("<br />","<br>","<br/>");  
    $editval = str_ireplace($breaks, "\r\n", $_POST["editval"]); 
	$editval = addslashes($editval);

$result = $db_handle->executeUpdate("UPDATE production_details set " . $_POST["column"] . " = '".trim($editval)."' WHERE  id=".$_POST["id"]);
?>