<?php
//processing form submitted
include('timeout.php');
require_once("dbcontroller.php");
session_start();

//include PHPExcel library
require_once dirname(__FILE__) . '/PHPExcel.php';

$objPHPExcel = new PHPExcel();

// Create a first sheet
 
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setCellValue('A1', "Sl.No");
$objPHPExcel->getActiveSheet()->setCellValue('B1', "Name of client");
$objPHPExcel->getActiveSheet()->setCellValue('C1', "Customer id");
$objPHPExcel->getActiveSheet()->setCellValue('D1', "Policy number");
$objPHPExcel->getActiveSheet()->setCellValue('E1', "Policy type");
$objPHPExcel->getActiveSheet()->setCellValue('F1', "Insurer");
$objPHPExcel->getActiveSheet()->setCellValue('G1', "No of workers");
$objPHPExcel->getActiveSheet()->setCellValue('H1', "Description");
$objPHPExcel->getActiveSheet()->setCellValue('I1', "Premium");
$objPHPExcel->getActiveSheet()->setCellValue('J1', "Premium wgst");
$objPHPExcel->getActiveSheet()->setCellValue('K1', "Commission1");
$objPHPExcel->getActiveSheet()->setCellValue('L1', "Commission2");
$objPHPExcel->getActiveSheet()->setCellValue('M1', "Agency Com");
$objPHPExcel->getActiveSheet()->setCellValue('N1', "Agent name");
$objPHPExcel->getActiveSheet()->setCellValue('O1', "Agent_com");
$objPHPExcel->getActiveSheet()->setCellValue('P1', "Referral_name");
$objPHPExcel->getActiveSheet()->setCellValue('Q1', "Referral");
$objPHPExcel->getActiveSheet()->setCellValue('R1', "Referral_com");
$objPHPExcel->getActiveSheet()->setCellValue('S1', "Com paid by insurer");
$objPHPExcel->getActiveSheet()->setCellValue('T1', "Com paid outto referral date");
$objPHPExcel->getActiveSheet()->setCellValue('U1', "Com paid date");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Difference in com");
$objPHPExcel->getActiveSheet()->setCellValue('W1', "Premium outstanding");
$objPHPExcel->getActiveSheet()->setCellValue('X1', "DN");
$objPHPExcel->getActiveSheet()->setCellValue('Y1', "Premium paid to insurer");
$objPHPExcel->getActiveSheet()->setCellValue('Z1', "Premium paid by client");

 
if((isset($_SESSION['SESSION_production_export'])) and strlen($_SESSION['SESSION_production_export']) > 0) {
	$sql = $_SESSION['SESSION_production_export'];
} else {
	 $sql = "SELECT pde.id, clist.company_name as name_of_client, clist.customer_id, pde.policy_number, pde.policy_type, pde.insurer, pde.no_of_workers, pde.description, pde.premium, pde.premium_wgst, pde.commission1, pde.commission2,pde.agency_com, alist.agent_name, pde.agent_com, pde.referral_name, pde.referral, pde.referral_com, pde.com_paid_by_insurer, pde.com_paid_outto_referral_date, pde.com_paid_date, pde.difference_in_com, pde.premium_outstanding, pde.dn, pde.premium_paid_to_insurer, pde.premium_paid_by_client FROM production_details as pde
			INNER JOIN company_list as clist on clist.id = pde.company_id  
			INNER JOIN agent_list as alist on alist.id = pde.agent_id  
			LEFT JOIN tbllogin as login on login.id = pde.updated_by order by id desc LIMIT 100";
}

$result = mysql_query($sql);
$rowCount = mysql_num_rows($result);
	
// Add data
for ($i = 2; $i <= $rowCount+1; $i++) 
{
	$row = mysql_fetch_array($result);

	$objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $i-1)
									->setCellValue('B' . $i, $row['name_of_client'])
									->setCellValue('C' . $i, $row['customer_id'])
									->setCellValue('D' . $i, $row['policy_number'])
									->setCellValue('E' . $i, $row['policy_type'])
									->setCellValue('F' . $i, $row['insurer'])
									->setCellValue('G' . $i, $row['no_of_workers'])
									->setCellValue('H' . $i, $row['description'])
									->setCellValue('I' . $i, $row['premium'])
									->setCellValue('J' . $i, $row['premium_wgst'])
									->setCellValue('K' . $i, $row['commission1'])
									->setCellValue('L' . $i, $row['commission2'])
									->setCellValue('M' . $i, $row['agency_com'])
									->setCellValue('N' . $i, $row['agent_name'])
									->setCellValue('O' . $i, $row['agent_com'])
									->setCellValue('P' . $i, $row['referral_name'])
									->setCellValue('Q' . $i, $row['referral'])
									->setCellValue('R' . $i, $row['referral_com'])
									->setCellValue('S' . $i, $row['com_paid_by_insurer'])
									->setCellValue('T' . $i, $row['com_paid_outto_referral_date'])
									->setCellValue('U' . $i, $row['com_paid_date'])
									->setCellValue('V' . $i, $row['difference_in_com'])
									->setCellValue('W' . $i, $row['premium_outstanding'])
									->setCellValue('X' . $i, $row['dn'])
									->setCellValue('Y' . $i, $row['premium_paid_to_insurer'])
									->setCellValue('Z' . $i, $row['premium_paid_by_client']);
}


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('production Details');

$sharedStyle1 = new PHPExcel_Style();
$sharedStyle1->applyFromArray(
	array('fill' 	=> array(
								'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
								'color'		=> array('argb' => 'FFFFFF00')
							),
		'font' 	=> array(
								//'name'      =>  'Arial',
								//'size'      =>  6,
								'bold'      => true
							),	
		'alignment' => array(
								'wrap' => false,
								'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT								
							),
		  'borders' => array(
								'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM),//BORDER_THIN
								'right'		=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM)
							)
		 ));
$objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle1, "A1:Z1");

// Save Excel 95 file

$callStartTime = microtime(true);

$filename = "production_details".date('Ymdhms').'.xls';
/*header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$filename.'"');
header('Cache-Control: max-age=0');*/

// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$filename.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');  //downloadable file is in Excel 2003 format (.xls)
ob_clean();
$objWriter->save('php://output');  //send it to user, of course you can save it to disk also!
 

//exit; //done.. exiting!

?>
