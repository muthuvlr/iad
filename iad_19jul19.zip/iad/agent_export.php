<?php
//processing form submitted
include('timeout.php');
require_once("dbcontroller.php");
session_start();

//include PHPExcel library
require_once dirname(__FILE__) . '/PHPExcel.php';
 
$objPHPExcel = new PHPExcel();

// Create a first sheet
 
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setCellValue('A1', "Sl.No");
$objPHPExcel->getActiveSheet()->setCellValue('B1', "Agent Name");
$objPHPExcel->getActiveSheet()->setCellValue('C1', "Date Joined");
$objPHPExcel->getActiveSheet()->setCellValue('D1', "Abb");
$objPHPExcel->getActiveSheet()->setCellValue('E1', "Cell Number");
$objPHPExcel->getActiveSheet()->setCellValue('F1', "Email Id");

 
 	if((isset($_SESSION['SESSION_agent_EXPORT'])) and strlen($_SESSION['SESSION_agent_EXPORT']) > 0)
	{
		$sql = $_SESSION['SESSION_agent_EXPORT'];
	}
	else
	{
		 $sql = "Select * from agent_list order by id desc LIMIT 100";
	}

	$result = mysql_query($sql);
	$rowCount = mysql_num_rows($result);
	
// Add data
for ($i = 2; $i <= $rowCount+1; $i++) 
{
	$row = mysql_fetch_array($result);
	$date_joined = date('d-m-Y H:i:s',strtotime($row['date_joined']));
	$created_on = date('d-m-Y',strtotime($row['created_on']));

	
	$date_joined = ($date_joined>'01-01-2000') ? $date_joined : ''; 
	$date_of_deployment = ($date_of_deployment>'01-01-2000') ? $date_of_deployment : ''; 
	
	$objPHPExcel->getActiveSheet()->setCellValue('A' . $i, $i-1)
									->setCellValue('B' . $i, $row['agent_name'])
									->setCellValue('C' . $i, $date_joined)
									->setCellValue('D' . $i, $row['abb'])
									->setCellValue('E' . $i, $row['cell_number'])
									->setCellValue('F' . $i, $row['email_id']);
}


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Agent_Details');

$sharedStyle1 = new PHPExcel_Style();
$sharedStyle1->applyFromArray(
	array('fill' 	=> array(
								'type'		=> PHPExcel_Style_Fill::FILL_SOLID,
								'color'		=> array('argb' => 'FFFFFF00')
							),
		'font' 	=> array(
								//'name'      =>  'Arial',
								//'size'      =>  6,
								'bold'      => true
							),	
		'alignment' => array(
								'wrap' => false,
								'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT								
							),
		  'borders' => array(
								'bottom'	=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM),//BORDER_THIN
								'right'		=> array('style' => PHPExcel_Style_Border::BORDER_MEDIUM)
							)
		 ));
$objPHPExcel->getActiveSheet()->setSharedStyle($sharedStyle1, "A1:F1");

// Save Excel 95 file

$callStartTime = microtime(true);

$filename = "Agent_details_".date('Ymdhms').'.xls';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$filename.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');  //downloadable file is in Excel 2003 format (.xls)
ob_clean();
$objWriter->save('php://output');  //send it to user, of course you can save it to disk also!
 

//exit; //done.. exiting!

?>