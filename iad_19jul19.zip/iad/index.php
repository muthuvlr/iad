<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
<title>MaraiCar Agency Production Software</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="A complete admin panel theme">
<meta name="author" content="theemio">
<link rel="shortcut icon" href="img/logo.png" />
<link href="css/utopia-white.css" rel="stylesheet">
<link href="css/utopia-responsive.css" rel="stylesheet">
<link href="css/validationEngine.jquery.css" rel="stylesheet">
<link href="less/index.less" rel="stylesheet/less">
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]--></head>
<body>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="span12">
			<div class="header-top" style="height:580px;width:99%;">
				<div class="row-fluid">
					<br/>
					<br/>
					<br/>
					<br/>
					<br/>
		<div class="span12">
			<div class="row-fluid">
				<div class="span4">
				
				</div>

				<div class="span4">
					<div class="utopia">
					
						<h3 class="utopia"><img alt="login" src="img/login.png" alt="image" width="160px" height="70px"><br>MaraiCar Agency Production Login </h3>
						<form action="login-exec.php" method="post" class="utopia">
							<label>Username:</label>
							<input type="text" name="username" id="username" class="span12 utopia-fluid-input validate[required]" value="">
							<label>Password:</label>
							<input type="password" name="password" id="password" autocomplete="off" class="span12 utopia-fluid-input validate[required]" value="">
							<ul class="utopia-login-action">
								<br/>
							<input style="width:90%;" type="submit" class="btn btn-success span5" value="Login">
							</ul>
						</form>
					</div>
				</div>

			</div>
		</div>
	</div>
			</div>
		</div>
	</div>

	
</div>

<script type="text/javascript" src="js/jquery.min.js"></script><script type="text/javascript" src="js/utopia.js"></script>
<script type="text/javascript" src="js/jquery.validationEngine.js"></script>
<script type="text/javascript" src="js/jquery.validationEngine-en.js"></script>
<script type="text/javascript">
jQuery(function(){
jQuery(".utopia").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
</body>
</html>