<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
$db_handle = new DBController();
/* Code */
$sesRolesUpdate = $_SESSION['SESSION_roles_update'];
$dataDelete = $_SESSION['SESSION_data_delete'];
?>
<link href="css/jquery-ui-1.10.4.custom.css" rel="stylesheet">
<script type="text/javascript">
$(document).ready(function () 
{
	$('.clsdelete').click(function()
	{
		
		var essay_id = $(this).attr('id');
		var x;
		if (confirm("Do you want to delete?") == true) 
		{
			$.ajax({
			  type : 'post',
			   url : 'roles_delete.php?', // in here you should put your query 
			  data :  'id='+ essay_id, // here you pass your id via ajax .
						 // in php you should use $_POST['post_id'] to get this value 
			success : function(r)
			   {
				  // now you can show output in your modal 
				  $('#mymodal').show();  // put your modal id 
				 $('.something').show().html(r);
			   }
			});

		} else 
		{
			//x = "You pressed Cancel!";
			//alert(x + essay_id);
		}
    });
});
</script>
<script type="text/javascript">
jQuery(function(){
jQuery(".form-horizontal").validationEngine("attach",{promptPosition:"topLeft",scroll:false})
});
</script>
<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12" style="width:100%">

	<!-- Individual Page Widget-->
	<form name="roles" method="get">	
	<div class="row-fluid">
	<div class ="ac">
		<div class="span12">
			<section class="utopia-widget">
	<div class="utopia-widget-title"><img src="img/icons/paragraph_justify.png" class="utopia-widget-icon"><span>Roles & Permission Details</span></div>
	
	<div class="utopia-widget-content">
	<?php
	$sql = "";
	if(isset($_POST['submit']))
	{
	} 
	else 
	{
		$sql = "SELECT * FROM tblroles";
	}
	$result = mysql_query($sql);
	$numrows = mysql_num_rows($result);
	
	?> 
	 <div style="width:100%; height:300px; overflow:auto;">
	<table style="float:left;" class="table table-bordered" id="example" cellpadding="0">
		<tr>
							<th width="5%"><center>Sl.No</center></th>
							<th width="9%"><center>Role Name</center></th>
							<th width="5%"><center>Production List</center></th>
							<th width="5%"><center>Company list</center></th>
							<th width="5%"><center>Agent list</center></th>
							<th width="5%"><center>Insurer list</center></th>
							<th width="5%"><center>Export</center></th>
							<th width="5%"><center>Database</center></th>
							<th width="5%"><center>User</center></th>
							<th width="5%"><center>Roles</center></th>
							<?php if ($sesRolesUpdate == "1") { ?>
							<th width="3%"><center>Edit</center></th>
							<?php } if ($dataDelete == "1") { ?>
							<th width="3%"><center>Del</center></th>
							<?php } ?>	
						</tr>
		<tr>

				<?php 
					$i = 0;
					while($i < $numrows)
					{
						$row = mysql_fetch_array($result);
						//echo '<pre>';
						//print_r($row);
						//echo '</pre>';
						$sid= $i+1;
						$id = $row['id'];
						$roles = $row['role_name'];
						$export = $row['export'];
						$user_profile = $row['user_profile'];
						$roles_update = $row['roles_update'];
						$productionlist = $row['productionlist'];
						$companylist = $row['companylist'];
						$agentlist = $row['agentlist'];
						$insurerlist = $row['insurerlist'];
						$delete = $row['data_delete'];
						$roles_view = $row['roles_view'];
						?>
						
						<tr>
						
						<td style="padding:2px;text-align: center;"><?php echo $sid;?></td>
						<td style="padding:2px;"><?php echo $roles;?></td>

						
						<?php if ($productionlist == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($companylist == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($agentlist == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						<?php if ($insurerlist == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($export == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($delete == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>

						<?php if ($user_profile == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($roles_view == "1"){?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_green.png" class="utopia-widget-icon" ></td>
						<?php }else{?>
							<td style="padding:2px;">
							<img id="statusicon" name="statusicon" src="img/bullet_red.png" class="utopia-widget-icon" ></td>
						<?php }?>
						
						<?php if ($sesRolesUpdate == "1") { ?>
						<td style="padding:2px;">
							<a style="color:black;" href="#" id="<?php echo $id;?>" class="abc" onclick="window.location.href = 'roles_update.php?id=' + <?php echo $id;?>">
							<img id="eidtico" name="eidtico" src="img/edit-icon.png" class="utopia-widget-icon" >
							</a>
						</td>
						<?php } 
						if ($dataDelete == "1") { ?>
						<td  style="padding:2px;">
								<a style="color:black;" href="#" id="<?php echo $id;?>" class="clsdelete" >
								<img id="deleteico" name="deleteico" src="img/delete-icon.png" class="utopia-widget-icon"></a>
						</td>
						<?php } ?> 
						</tr>
						
						<?php
						  $i++;
					} //end of while		
					?>
				
	</table>
	</div>
	<table style="float:left;" class="table table-bordered" id="example1" cellpadding="0">
		<tr>
					<td>Displaying <?php echo $numrows; ?> results.</td>
				</tr>
				<?php if ($sesRolesUpdate == "1") { ?>
				<tr>
					<td>
						<a style="color:black;" href="#" id="addroles" class="abc" onclick="window.location.href = 'roles_add.php'">
						<img id="deleteico" name="deleteico" src="img/Add-icon.png" ></a><b> Create new record.</b>
					</td>
					
				</tr>
				<?php } ?> 
	</table>
	

	</div>
	<div class="modal-body">  
					<div class="something" style="display:none;">

					</div>
				</div>
	</section>
	</div>
	</div>
	</div>
	<!-- Individual Page Widget-->

</div>
</form>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>