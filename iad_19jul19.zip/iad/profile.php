<?php 
include('auth.php'); //User Authentication
include('header.php'); //header section
include('timeout.php');
require_once("dbcontroller.php");
/* Code */
	$user_id = $_SESSION['SESSION_USER_ID'];
	//echo $user_id ;
	$result = mysql_query("select * from tbllogin where id = $user_id");
	$row = mysql_fetch_array($result);

?>

<!-- Start Body Content -->
<div class="span10 body-container">
<div class="row-fluid"></div>
<div class="row-fluid">
<div class="span12">
<div class="row-fluid">
<div class="span9">
	
	<!-- Individual Page Widget-->
	<section id="formElement" class="utopia-widget utopia-form-box section">
	<div class="utopia-widget-title"><img src="img/icons2/software24.png" class="utopia-widget-icon"><span>Profile</span></div>
	<div class="row-fluid">
	<div class="utopia-widget-content">
	<div class="span6 utopia-form-freeSpace">
		<form method="post" action="" class="form-horizontal">
			<fieldset>
				<div class="control-group">
				<label class="control-label" for="input01">First Name</label>
				<div class="controls"><input disabled style="width:200px" id="first_name" name="first_name" class="span12" value="<?php echo $row['first_name'];?>" type="text"></div>
				</div>
				</br>
				<div class="control-group">
				<label class="control-label" for="input01">Last Name</label>
				<div class="controls"><input disabled style="width:200px" id="last_name" name="last_name" class="span12 " value="<?php echo $row['last_name'];?>" type="text"></div>
				</div>
				</br>
				<div class="control-group">
				<label class="control-label" for="input01">User Name</label>
				<div class="controls"><input disabled style="width:200px" id="active" name="user_name" class="span1" value="<?php echo $row['user_name'];?>" type="text"></div>
				</div>
				</br>
				<div class="control-group">
				<label class="control-label" for="input01"></label>
				<div class="controls">
				<a class="btn btn-success span5" style="width:160px;" href="change_password.php">Change Password</a>
				</div>
				</div>
				
			</fieldset>
		</form><br/><br/>
	</div>
	</div>
	</div>
	</section>
	
</div>
</div>
</div>
</div>
</div>
<!-- End Body Content -->

<?php /* footer */
include('footer.php'); //footer section
?>

