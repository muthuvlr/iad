<?php 
error_reporting(0);
include('timeout.php');
require_once("dbcontroller.php");

	$user_name= $_REQUEST["user_name"];
	$password= $_REQUEST["password"];
	$first_name= $_REQUEST["first_name"];
	$last_name= $_REQUEST["last_name"];
	$user_level= $_REQUEST["user_level"];
	$short_name= $_REQUEST["short_name"];
	$email_id= $_REQUEST["email_id"];
	$active = $_REQUEST["active"];
	//$password= crypt(strrev($_POST['password']),strrev('pwd321'))
	
	$sql = "INSERT INTO tbllogin (user_name,password,first_name,last_name,user_level,active,short_name,email_id) 
	VALUES ('$user_name','$password','$first_name','$last_name','$user_level', $active,'$short_name','$email_id')";

	$result = mysql_query($sql);

	$sql1 = "UPDATE tbllogin, tblroles SET tbllogin.role_id = tblroles.id 
	WHERE tbllogin.user_level = tblroles.role_name and tbllogin.role_id = '0'";
	$result = mysql_query($sql1);
	//echo "Record updated successfully";
	
?>	

<div class="message">Your record was added successful.</div><br/>
<br/>

