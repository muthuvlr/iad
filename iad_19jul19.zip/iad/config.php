<?php
    define('CR_VERSION','1.0'); 
    
    define('DB_HOST', 'localhost');
    define('DB_USER', 'iaddevuser');
    define('DB_PASSWORD', 'Netcom123');
    define('DB_DATABASE', 'insurance-agent');


?>
