<?php 
error_reporting(0);
include('timeout.php');
require_once("dbcontroller.php");

	$post_id = $_REQUEST["post_id"];
	
	$sql = "SELECT * FROM tbllogin WHERE id = $post_id";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);

	$id= $row['Id'];
	$user_name= $row['user_name'];
	$password= $row['password'];
	$first_name= $row['first_name'];
	$last_name= $row['last_name'];
	$user_level= $row['user_level'];
	$short_name= $row['short_name'];
	$email_id= $row['email_id'];
	$active= $row['Active'];

?>	

<input type="hidden" readonly id="updateid" name="updateid" value="<?php echo $id;?>"/>
<input type="hidden" readonly id="short_nameold" name="short_nameold" value="<?php echo $short_name;?>"/>
<table><tr><td  width="120px">
<label>User Name *: </label>
</td>
<td><input required type="text" id="user_name" name="user_name" class="span12 utopia-fluid-input validate[required]" value="<?php echo $user_name;?>"/> 
</td>
</tr>
<tr><td><label>Password *: </label>
</td><td><input required type="text" id="password" name="password" class="span12 utopia-fluid-input validate[required]" value="<?php echo $password;?>"/>
</td>
</tr>

<tr><td><label>Confirm Password *: </label>
</td><td><input required type="text" id="conformpassword" name="conformpassword" class="span12 utopia-fluid-input validate[required]" value="<?php echo $password;?>"/>
</td>
</tr>

<tr><td><label>First Name *: </label>
</td><td><input required type="text" id="first_name" name="first_name" value="<?php echo $first_name;?>"/> 
</td>
</tr>
<tr><td><label>Last Name : </label>
</td><td><input type="text" id="last_name" name="last_name" value="<?php echo $last_name;?>"/>
</td>
</tr>
<tr><td><label>Short Name : </label>
</td><td><input type="text" id="short_name" name="short_name" value="<?php echo $short_name;?>"/>
</td>
</tr>
<tr><td><label>EmailId : </label>
</td><td><input type="text" id="email_id" name="email_id" value="<?php echo $email_id;?>"/>
</td>
</tr>
<tr><td><label>User Role *: </label>
</td><td> <select required style="width:220px;" id="user_level" name="user_level" class="span6">
						<option><?php echo $user_level;?></option>
						<?php
						$res = mysql_query("SELECT * FROM tblroles Where role_name NOT IN ('".$user_level."') order by  role_name");
						$num_rows = mysql_num_rows($res);
						if($num_rows >0)
						{
							while($row = mysql_fetch_assoc($res))
						{
							echo "<option>$row[role_name]</option>";
						}
						}
						?>
					</select>
</td>
</tr>
<tr><td><label>Active *: </label>
</td><td>
	<select required name="active" id="active" >
			<option value="1" <?php if($active=='1') { echo "Selected"; }?> >Active</option>
			<option value="0" <?php if($active=='0') { echo "Selected"; }?> >In-Active</option>
	</select>  <br/>
</td> 
</tr>
</table>
<br/>




